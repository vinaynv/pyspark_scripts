# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql.functions import col, lit
from pyspark.sql import SparkSession
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from uuid import uuid4
from time import *
import time
from datetime import datetime as dt

#Logging 
import logging
import traceback
import sys
import os

import json
import argparse
import collections   
import requests
from requests.exceptions import HTTPError

from azure.storage.blob import BlobClient, BlobServiceClient, ContainerClient

# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)

# COMMAND ----------

cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Source blob store
source_blob_path = 'confluent/p1_streaming_data_26'
azure_source_path = 'wasbs://cpods-kafka-storage@cpodsdev.blob.core.windows.net/'+ source_blob_path
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

source_container = 'cpods-kafka-storage'
target_container ='cpods-dev-storage'

blob_folder_path = 'penske_predict/seq/pq_1rec/'
target_blob_path = 'wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/'+ blob_folder_path

connection_string = 'DefaultEndpointsProtocol=https;AccountName=cpodsdev;AccountKey=fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg==;EndpointSuffix=core.windows.net'

p0_endpoint = 'https://fleetmaintenance-fp-cpods.azurewebsites.net/batch'


# COMMAND ----------

def get_spark(app_name):
    """
        Creates Spark session with default parameters
    """
    spark = SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()

    # Other hadoop configs
    hadoop_config = spark.sparkContext._jsc.hadoopConfiguration()
    hadoop_config.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)

    return spark

# COMMAND ----------

#Creates Spark session with default parameters
spark = get_spark("fault events aggregations")
spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.sparkContext.setLogLevel("ERROR")


# COMMAND ----------

def get_p0_predictions(filePath):
    """ This function sends request to the URL and get prediction
    in the form of response"""
    try:
      # Send the post request and get response   
      logger.info("Input blob to model : %s" % filePath)
      data = json.dumps({"jobId": "df80fc82-2bd3-4099-a70d-pensketry2", 
                          "modelName": "fleet_maintenance.penske_models",
                          "predictionInput": {
                            "modelPath": "Model_Output/",
                            "dataFormat": "JSON",
                            "args": [ "--sensor_data_paths", filePath ], 
                            "fromSource": "File Storage",
                            "toTarget": "Database", 
                            "sourceType": "parquet"
                          } })
      headers = {"content-type": "application/json"}
      logger.info('API request %s' , data)
      requestStartTime = time.time()
      response = requests.post(p0_endpoint, data=data, headers=headers)
      timeTaken = time.time() - requestStartTime
      logger.info('Time taken for Analyzer API request: %f seconds' % timeTaken)
      returnResponse = None
      
      if response.status_code == requests.codes.ok:
         returnResponse = response
      else:
          logger.info('Model API returns HTTP error %s for input file: %s', response.status_code, filePath)
          response.raise_for_status()
    except HTTPError as http_err:
        logger.error(http_err)
        pass
    except Exception as err:
        logger.error(err)
        pass
    return returnResponse

#Create azure blob service client
def create_blob_service_client(source_container_connection_string, source_container_name):
    container_client = None
    try:
        blob_source_service_client = BlobServiceClient.from_connection_string(source_container_connection_string)
        container_client = blob_source_service_client.get_container_client(source_container_name)
    except Exception as ex:
        logger.info("Getting blob connection :" , repr(ex))
        raise Exception("Error while creating azure blob container client.")
        
    return container_client
  
# Preapre a list with blob images from source path 
def isBlobExists(connection_client, inutSourceFolderPath):
    isExists = False
    blob_names = []
    try:
        blob_list = connection_client.list_blobs(inutSourceFolderPath)
        for blob in blob_list:
            blob_name = blob.name
            #logger.info("blob_name: %s" % blob_name)
            if blob_name.find("part-") != -1 :
                #connection_client.delete_blob(blob=blob_name)
                #blob_names.append(blob_name)
                isExists = True
        #print(blob_names)
    except Exception as ex:
        logger.error("Exception occured while preparing blobs list... %s", str(ex))
        
    return isExists

def run_pipeline():
    #Load all the data from blob
    
    all_data = spark.read.format("parquet").load(azure_source_path)
    logger.info('======= all data from blob loaded ============')
    
    five_min_vins_rows = all_data.filter((col("last_updated_ts") >= (to_timestamp(lit('2022-05-30 10:00:00'),'yyyy-MM-dd HH:mm:ss') - expr("INTERVAL 5 minutes"))) & (col("last_updated_ts") < to_timestamp(lit('2022-05-30 10:00:00'),'yyyy-MM-dd HH:mm:ss'))).groupBy('eventVIN').count().select("eventVIN").collect()
    five_min_vins_list = [row.eventVIN for row in five_min_vins_rows]
    logger.info('=======No.of VINs updated =========== : %s' % len(five_min_vins_list))
    #five_min_vins_rows.show()
    
    #tt=five_min_vins_rows.agg(approx_count_distinct("eventVIN"))
    #five_min_vins_list = [row.eventVIN for row in tt]
    #logger.info('=======No.of VINs updated usig sql 1=========== %s' % all_data.rdd.isEmpty())
    #logger.info('=======No.of VINs updated usig sql 2=========== ')
    #tt.show()
    #logger.info('=======No.of VINs updated usig sql =========== ')
    
    #all_data.createOrReplaceTempView("parquetTable")
    #all_data = spark.read.format("parquet").load(azure_source_path).filter((col("last_updated_ts") >= (to_timestamp(lit('2022-05-30 10:00:00'),'yyyy-MM-dd HH:mm:ss') - expr("INTERVAL 5 minutes"))) & (col("last_updated_ts") < to_timestamp(lit('2022-05-30 10:00:00'),'yyyy-MM-dd HH:mm:ss'))).select('eventVIN').distinct().collect()
    #fil_data_vin=spark.sql("select distinct eventVIN from parquetTable where last_updated_ts >= (current_timestamp - INTERVAL '5' minute)")
    #fil_data_vin=spark.sql("select distinct eventVIN,last_updated_ts from parquetTable where last_updated_ts >= (CAST('2022-05-30 10:00:00' as timestamp) - INTERVAL '5' minute) and last_updated_ts < CAST('2022-05-30 10:00:00' as timestamp)")
    #fil_data_vin.show()
    #fil_data_vin_l = [row.eventVIN for row in fil_data_vin]
    #logger.info('=======No.of VINs updated usig sql =========== : %s' % tt)

    
    #five_min_vins_rows = all_data.filter((col("last_updated_ts") >= (to_timestamp(lit('2022-05-30 10:00:00'),'yyyy-MM-dd HH:mm:ss') - expr("INTERVAL 5 minutes"))) & (col("last_updated_ts") < to_timestamp(lit('2022-05-30 10:00:00'),'yyyy-MM-dd HH:mm:ss'))).select('eventVIN').distinct().collect()
    #five_min_vins_list = [row.eventVIN for row in five_min_vins_rows]
    #logger.info('=======No.of VINs updated =========== : %s' % len(five_min_vins_list))

                    

# COMMAND ----------

def main():
    job_start_time = time.time()
    logger.info('========== JOB-2 STARTED :==========' )
    try:
        run_pipeline()
        execution_time = time.time() - job_start_time
        logger.info("Time taken to complete Job-2: %s seconds" % execution_time)
        logger.info("========== JOB-2 ENDS ===========>>" )
    except Exception as ex:
        logger.info(f"{traceback.format_exc()}")
        logger.info("Exception from main:" , ex)

if __name__ == "__main__":
    main()
    