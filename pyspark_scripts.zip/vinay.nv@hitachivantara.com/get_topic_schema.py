# Databricks notebook source
from pyspark.sql.types import *

import json

from confluent_kafka.schema_registry import SchemaRegistryClient

confluentRegistryApiKey="Z5YNYU7PWAD7DPWZ"
confluentRegistrySecret="SNUZ5TqdXB8u+v96EgJn4PQDEJoP2YLzlVYqE1Nwo1gGPDPmaibyWwCM9kb++wph"

schema_registry_conf = {
    'url': 'https://psrc-q2n1d.westus2.azure.confluent.cloud',
    'basic.auth.user.info': '{}:{}'.format(confluentRegistryApiKey, confluentRegistrySecret)}

schema_registry_client = SchemaRegistryClient(schema_registry_conf)
subjects = schema_registry_client.get_subjects()

schema = schema_registry_client.get_latest_version("cust_eve_data-value")
print(schema.version)
print(schema.schema_id)
print(schema.schema.schema_str)

SchemaConverters.toSqlType(schema.schema.schema_str).dataType.asInstanceOf[StructType]



#for subject in subjects:
#    schema = schema_registry_client.get_latest_version(subject)
#    print(schema.version)
#    print(schema.schema_id)
#    print(schema.schema.schema_str)



