# Databricks notebook source
#Required libraries.
import ssl
#from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
#from pyspark.sql.types import LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, lit, row_number
from time import *
import time
from datetime import datetime as dt

#Logging 
import logging
import traceback
import sys

import json
import argparse
import collections   
import requests
from requests.exceptions import HTTPError

from azure.storage.blob import BlobClient,BlobServiceClient,  ContainerClient

# COMMAND ----------

#Source blob store
source_blob_path = 'confluent/Incident_merged_streamed_data_110'
azure_source_path = 'wasbs://cpods-kafka-storage@cpodsdev.blob.core.windows.net/'+ source_blob_path
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Source blob store
blob_folder_path = 'penske_predict/seq/pq_2rec/'
target_blob_path = 'wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/'+ blob_folder_path

source_container = 'cpods-kafka-storage'
target_container ='cpods-dev-storage'
connection_string = 'DefaultEndpointsProtocol=https;AccountName=cpodsdev;AccountKey=fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg==;EndpointSuffix=core.windows.net'

model_endpoint = 'https://fleetmaintenance-fp-cpods.azurewebsites.net/batch'


# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)

# COMMAND ----------

# STEP 1 : creating spark session object
spark = (
      spark.builder.appName("Fault Events aggregations")
      .master("local[*]")
      .getOrCreate()
  )

spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
#spark.conf.set("spark.sql.streaming.statefulOperator.checkCorrectness.enabled", False)
spark.conf.set("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false")
spark.sparkContext.setLogLevel("ERROR")
spark.conf.set("spark.sql.sources.commitProtocolClass", "org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol")
spark.conf.set("parquet.enable.summary-metadata", "false")



# COMMAND ----------

blob_data = spark.read.format("parquet").load(azure_source_path)

# COMMAND ----------

    blob_data = spark.read.format("parquet").load(azure_source_path)
    blob_data.createOrReplaceTempView("all_records_temp")

    #Filter last 5 minutes data
    five_minutes_delta = sqlContext.sql("SELECT * FROM all_records_temp \
                 WHERE processing_time >= date_trunc('minute', now()) - interval '20000 minute' \
                 and processing_time < date_trunc('minute', now())")


    #apply aggregations
    #map events to closest odo records
   	
    mapped_data = five_minutes_delta \
                        .withColumn("process_time", F.unix_timestamp(F.col("processing_time"), 'yyyy-MM-dd HH:mm:ss.SS')) \
                        .drop("processing_time")
    
    mapped_data = mapped_data.orderBy(col("odometer").desc())
    #mapped_data.display()
    #generate sequences
    fault_seq_data = mapped_data.groupBy("unit_vin") \
        .agg(concat_ws(",", collect_list("odometer")).alias("mileage_seq"), 
             concat_ws(",", collect_list("incident_timestamp")).alias("event_ts_seq"), first("key").alias("uniquestr"),
             first('process_time').alias("processing_time")) \
        .select(col("unit_vin").alias("vin"),col("event_ts_seq"), col("mileage_seq"), col("uniquestr"), 
                lit("Un Resolved").alias("status"), col("processing_time"))
				


# COMMAND ----------

partition_folder_name = dt.now().strftime("%Y%m%d-%H%M%S")
target_file_path = target_blob_path + partition_folder_name

# COMMAND ----------

fault_seq_data.repartition(1).write.mode(saveMode="append").parquet(target_file_path)

# COMMAND ----------

      #Load all the data from blob
blob_data = spark.read.format("parquet").load(azure_source_path)
blob_data.createOrReplaceTempView("all_records_temp")

#Filter last 5 minutes data
five_minutes_delta = sqlContext.sql("SELECT * FROM all_records_temp \
             WHERE processing_time >= date_trunc('minute', now()) - interval '1000 minute' \
             and processing_time < date_trunc('minute', now())")

# COMMAND ----------

