# Databricks notebook source
#Logging 
import logging
import traceback
import sys
import os

# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)

# COMMAND ----------

cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Source blob store
#source_blob_path = 'confluent/incident'
azure_source_path = 'wasbs://cpods-kafka-storage@cpodsdev.blob.core.windows.net/'+ source_blob_path
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

source_container = 'cpods-kafka-storage'
target_container ='cpods-dev-storage'

blob_folder_path = 'penske_predict/seq/pq_1rec/'
target_blob_path = 'wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/'+ blob_folder_path

connection_string = 'DefaultEndpointsProtocol=https;AccountName=cpodsdev;AccountKey=fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg==;EndpointSuffix=core.windows.net'