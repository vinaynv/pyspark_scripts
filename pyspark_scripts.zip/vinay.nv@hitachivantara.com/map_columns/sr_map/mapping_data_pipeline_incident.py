# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql import SparkSession

from pyspark.sql.functions import col, lit
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from time import time
from datetime import datetime
from uuid import uuid4

import sys
import os
import time

#Logging 
import logging
import traceback
import sys
import json
import ast

from azure.storage.blob import BlobClient, ContainerClient
from pyspark.sql.functions import map_keys, map_values	

from confluent_kafka.schema_registry import SchemaRegistryClient
from jproperties import Properties


######### Modify target topic and Incident data pipeline accordingly############
######### Create checkpoint pat #####################

# COMMAND ----------

#All configuration properties.
configs = Properties()
with open('/dbfs/FileStore/tables/app3_properties-6', 'rb') as read_prop:
    configs.load(read_prop)
    
confluentRegistryApiKey= configs.get("confluentRegistryApiKey").data
confluentRegistrySecret= configs.get("confluentRegistrySecret").data
bootstrapServers = configs.get("bootstrapServer").data
confluentApiKey = configs.get("apiKey").data
confluentSecret = configs.get("secret").data
schema_reg_url = configs.get("schema_reg_url").data

cpods_dev_config_key = configs.get("cpods_dev_config_key").data
cpods_dev_blob_access_key = ast.literal_eval(configs.get("cpods_dev_blob_access_key").data)

fleet_dev_config_key = configs.get("fleet_dev_config_key").data
fleet_dev_blob_access_key = ast.literal_eval(configs.get("fleet_dev_blob_access_key").data)

target_topic_events="hal_incident_data"
#Checkpoint paths configured on DBFS
events_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/hal_incident_data_delta_12"

# COMMAND ----------


#Configure widgets params JSON blob paths
dbutils.widgets.text("incident_mapping_json", "")
#dbutils.widgets.text("units_mapping_json", "")
dbutils.widgets.text("customer_incident_topic", "")

source_topic_events = dbutils.widgets.get("customer_incident_topic")

# COMMAND ----------

schema_registry_conf = {
    'url': schema_reg_url,
    'basic.auth.user.info': '{}:{}'.format(confluentRegistryApiKey, confluentRegistrySecret)}
schema_registry_client = SchemaRegistryClient(schema_registry_conf)
incident_schema = schema_registry_client.get_latest_version(source_topic_events+'-value').schema.schema_str
print(incident_schema)

# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)


# COMMAND ----------

#Creates Spark session
def get_spark(app_name):
    return SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()


#Functions to flatten the data
def process_fault_incident(rawKafka_df):
    decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), from_avro(col("fixedValue"),incident_schema).alias("payload"))
    df1 = decoded_df.select("timestamp", "key", "payload.*")
    return df1 

# COMMAND ----------

#Functions to consume streams from kafka topics 
#Topic1:Subscribe to fault_events stream
def read_incident_stream():
  raw_fault_incident= spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", bootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", source_topic_events)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .withColumn('fixedValue', expr("substring(value, 6, length(value)-5)"))\
        .select(col("timestamp"), col("key"), col("fixedValue"))
  return process_fault_incident(raw_fault_incident)
     # return process_fault_events(raw_fault_events)

def map_fields(json_df, stream_df):
  fields = []
  df_json = json_df.toJSON()
  for row in df_json.collect():
      dict_items = json.loads(row) 
      for field in dict_items:
        stream_df = stream_df.withColumnRenamed(dict_items[field], field)
        fields.append(field)
  return stream_df
      

# COMMAND ----------

def write_to_topic_incidents(df, batch_id):
  
  logger.info("======= FM Streaming batch STARTS ========")
  batch_start_time = time.time()
  #Write to kafka
  logger.info("FM EVENTS stream is writing to kafka Topic: %s " % target_topic_events)
  df.selectExpr("CAST(uuid() AS STRING) AS key", "to_json(struct(*)) AS value") \
     .write \
     .format("kafka") \
     .option("kafka.bootstrap.servers", bootstrapServers) \
     .option("kafka.security.protocol", "SASL_SSL")\
	 .option("failOnDataLoss", "false")\
	 .option("topic", target_topic_events) \
     .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
     .option("kafka.sasl.mechanism", "PLAIN")\
     .option("kafka.ssl.endpoint.identification.algorithm", "https")\
     .save()
  
  time_taken_to_blob_write = time.time() - batch_start_time
  logger.info("Time taken for write to blob : %s seconds" % time_taken_to_blob_write)
  logger.info("======= FM Streaming batch ENDS ========")

# COMMAND ----------

#Creates Spark session with default parameters
spark = get_spark("fault events streaming")
#spark.conf.set("spark.sql.streaming.statefulOperator.checkCorrectness.enabled", False)
spark.conf.set(cpods_dev_config_key, cpods_dev_blob_access_key)
spark.sparkContext.setLogLevel("ERROR")

#Step: Read data from kafka topic (events)
incident = read_incident_stream()

input_incident_mappings = dbutils.widgets.get("incident_mapping_json")

incident_mapping_json = spark.read.option("multiline","true").json(input_incident_mappings)

incident_stream_df = map_fields(incident_mapping_json, incident)

#display(incident)

# COMMAND ----------

#Write to KAFKA as a micro batch
incident_stream_df.writeStream.trigger(processingTime="120 seconds") \
  .option("checkpointLocation", events_checkpoint_path)\
  .foreachBatch(write_to_topic_incidents)\
  .queryName("mappingIncidentStreamingQuery").start()