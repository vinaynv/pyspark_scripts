# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql import SparkSession

from pyspark.sql.functions import col, lit
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from time import time
from datetime import datetime

import sys
import os
import time

#Logging 
import logging
import traceback
import sys
import json

from azure.storage.blob import BlobClient, ContainerClient
from pyspark.sql.functions import map_keys, map_values	

from confluent_kafka.schema_registry import SchemaRegistryClient


# COMMAND ----------

#All configuration properties.
confluentBootstrapServers="pkc-ldvmy.centralus.azure.confluent.cloud:9092"
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Confluent account credentials
confluentApiKey="5WYK22HAT2WJ4VIQ"
confluentSecret="bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl"

confluentRegistryApiKey="Z5YNYU7PWAD7DPWZ"
confluentRegistrySecret="SNUZ5TqdXB8u+v96EgJn4PQDEJoP2YLzlVYqE1Nwo1gGPDPmaibyWwCM9kb++wph"

#Source topics
source_topic_events="avro_customer_fault_event"  
source_topic_units="avro_customer_odometer_units"

target_topic_events="events_mapping_output"
target_topic_units="units_mapping_output"

#Checkpoint paths configured on DBFS
events_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/map_stream_delta_11"
units_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/map_stream_delta_12"




# COMMAND ----------

schema_registry_conf = {
    'url': 'https://psrc-q2n1d.westus2.azure.confluent.cloud',
    'basic.auth.user.info': '{}:{}'.format(confluentRegistryApiKey, confluentRegistrySecret)}
schema_registry_client = SchemaRegistryClient(schema_registry_conf)
events_schema = schema_registry_client.get_latest_version(source_topic_events+'-value').schema.schema_str
units_schema = schema_registry_client.get_latest_version(source_topic_units+'-value').schema.schema_str

# COMMAND ----------

#Configure widgets params JSON blob paths
dbutils.widgets.text("events_mapping_json", "")
dbutils.widgets.text("units_mapping_json", "")
dbutils.widgets.text("topic", "")


# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)


# COMMAND ----------

#Creates Spark session
def get_spark(app_name):
    return SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()


#Functions to flatten the data
def process_fault_events(rawKafka_df):
    decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), from_avro(col("fixedValue"),events_schema).alias("payload"))
    df1 = decoded_df.select("timestamp", "key", "payload.*")

    return df1
  
def process_odometer_data(raw_df):
    df1 = raw_df.select(col("timestamp"), col('key').cast("string"), from_avro(col("fixedValue"), units_schema).alias("payload"))
    df1 = df1.select("timestamp", "key", "payload.*")
    return df1
  

  
  

# COMMAND ----------

#Functions to consume streams from kafka topics 
#Topic1:Subscribe to fault_events stream
def read_falut_events_stream():
      raw_fault_events= spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", source_topic_events)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .withColumn('fixedValue', expr("substring(value, 6, length(value)-5)"))\
        .select(col("timestamp"), col("key"), col("fixedValue"))
      return process_fault_events(raw_fault_events)
    
#Topic2:Subscribe to unit_locations stream 
def read_odometer_units_stream():
      raw_odometer_data= spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", source_topic_units)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .withColumn('fixedValue', expr("substring(value, 6, length(value)-5)"))\
        .select(col("timestamp"), col("key"), col("fixedValue"))
      return process_odometer_data(raw_odometer_data)
 
 
  
def map_fields(json_df, stream_df):
  fields = []
  df_json = json_df.toJSON()
  for row in df_json.collect():
      dict_items = json.loads(row) 
      for field in dict_items:
        stream_df = stream_df.withColumnRenamed(dict_items[field], field)
        fields.append(field)
  return stream_df
      

# COMMAND ----------

def write_to_topic_events(df, batch_id):
  
  logger.info("======= FM Streaming batch STARTS ========")
  batch_start_time = time.time()
  #Write to kafka
  logger.info("FM EVENTS stream is writing to kafka Topic: %s " % target_topic_events)
  df.selectExpr("CAST(vin AS STRING) AS key", "to_json(struct(*)) AS value") \
     .write \
     .format("kafka") \
     .option("kafka.bootstrap.servers", confluentBootstrapServers) \
     .option("kafka.security.protocol", "SASL_SSL")\
	 .option("failOnDataLoss", "false")\
	 .option("topic", target_topic_events) \
     .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
     .option("kafka.sasl.mechanism", "PLAIN")\
     .option("kafka.ssl.endpoint.identification.algorithm", "https")\
     .save()
  
  time_taken_to_blob_write = time.time() - batch_start_time
  logger.info("Time taken for write to blob : %s seconds" % time_taken_to_blob_write)
  logger.info("======= FM Streaming batch ENDS ========")
  
  
  
def write_to_topic_units(df, batch_id):
  logger.info("======= FM Streaming batch STARTS ========")
  batch_start_time = time.time()
  #Write to kafka
  logger.info("FM uNITS stream is writing to kafka Topic: %s" % target_topic_units)
  df.selectExpr("CAST(vin AS STRING) AS key", "to_json(struct(*)) AS value") \
     .write \
     .format("kafka") \
     .option("kafka.bootstrap.servers", confluentBootstrapServers) \
     .option("kafka.security.protocol", "SASL_SSL")\
	 .option("failOnDataLoss", "false")\
	 .option("topic", target_topic_units) \
     .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
     .option("kafka.sasl.mechanism", "PLAIN")\
     .option("kafka.ssl.endpoint.identification.algorithm", "https")\
     .save()
  
  time_taken_to_blob_write = time.time() - batch_start_time
  logger.info("Time taken for write to blob : %s seconds" % time_taken_to_blob_write)
  logger.info("======= FM Streaming batch ENDS ========")

# COMMAND ----------

#Creates Spark session with default parameters
spark = get_spark("fault events streamining")
#spark.conf.set("spark.sql.streaming.statefulOperator.checkCorrectness.enabled", False)
spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.sparkContext.setLogLevel("ERROR")

input_event_mappings = dbutils.widgets.get("events_mapping_json")
input_unit_mappings = dbutils.widgets.get("units_mapping_json")

events_mapping_json = spark.read.option("multiline","true").json(input_event_mappings)
units_mapping_json = spark.read.option("multiline","true").json(input_unit_mappings)

#Step: Read data from kafka topic (events)
events = read_falut_events_stream()
units = read_odometer_units_stream()

events_stream_df = map_fields(events_mapping_json, events)
units_stream_df = map_fields(units_mapping_json, units)
    



# COMMAND ----------

 #temp_df = events_stream_df.selectExpr("CAST(vin AS STRING) AS key", "to_json(struct(*)) AS value")

# COMMAND ----------

#decoded_df = events.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_fault_events_schema()).alias("payload"))

# COMMAND ----------

#decoded_df = events.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_fault_events_schema()).alias("payload"))

# COMMAND ----------

display(events_stream_df)


# COMMAND ----------

#Write to KAFKA as a micro batch
events_stream_df.writeStream.trigger(processingTime="120 seconds") \
  .option("checkpointLocation", events_checkpoint_path)\
  .foreachBatch(write_to_topic_events)\
  .queryName("mappingEventsStreamingQuery").start()

#Write to KAFKA as a micro batch
units_stream_df.writeStream.trigger(processingTime="120 seconds") \
     .option("checkpointLocation", units_checkpoint_path)\
     .foreachBatch(write_to_topic_units)\
     .queryName("mappingUnitsStreamingQuery").start()
