# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql import SparkSession

from pyspark.sql.functions import col, lit
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from uuid import uuid4
from time import time

import sys
import os

#Logging 
import logging
import traceback
import sys

from azure.storage.blob import BlobClient, BlobServiceClient, ContainerClient

import json
import re

# COMMAND ----------

#All configuration properties.
confluentBootstrapServers="pkc-ldvmy.centralus.azure.confluent.cloud:9092"
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Confluent account credentials
confluentApiKey="5WYK22HAT2WJ4VIQ"
confluentSecret="bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl"

topic_fault_events="cust_eve_data"

connection_string = 'DefaultEndpointsProtocol=https;AccountName=cpodsdev;AccountKey=fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg==;EndpointSuffix=core.windows.net'

json_container ='cpods-dev-storage/mappings'

# COMMAND ----------

def get_spark(app_name):
    """
        Creates Spark session with default parameters
    """
    spark = SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()

    return spark

# COMMAND ----------

#Creates Spark session with default parameters
spark = get_spark("fault events streamining")
spark.conf.set("spark.sql.streaming.statefulOperator.checkCorrectness.enabled", False)
spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.sparkContext.setLogLevel("ERROR")


# COMMAND ----------

def read_falut_events_stream():
      return spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", topic_fault_events)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))

# COMMAND ----------

def read_kafka_topic(topic):
  df_json=( spark.read \
      .format("kafka") \
      .option("kafka.bootstrap.servers", confluentBootstrapServers)\
      .option("kafka.security.protocol", "SASL_SSL")\
      .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
      .option("kafka.ssl.endpoint.identification.algorithm", "https")\
      .option("kafka.sasl.mechanism", "PLAIN")\
      .option("subscribe", topic)\
      .option("startingOffsets", "earliest")\
      .option("failOnDataLoss", "false")\
      .option("includeHeaders", "true")\
      .load() \
      .withColumn("value", expr("string(value)")) \
      .filter(col("value").isNotNull()) \
      .select("key", expr("struct(offset, value) r")) \
      .groupBy("key").agg(expr("max(r) r")) \
      .select("r.value"))

# decode the json values
  df_read = spark.read.json(
      df_json.rdd.map(lambda x: x.value), multiLine=True)

    
  df_read.show()
  return df_read



# COMMAND ----------

rawdata_fault_events = read_kafka_topic(topic_fault_events)
print(rawdata_fault_events.schema.fields)

topic_col=rawdata_fault_events.schema.names
schema_topic=rawdata_fault_events.schema.fields
print(rawdata_fault_events.schema.names)

def create_fault_events_schema():
  return StructType(schema_topic)

# COMMAND ----------



rawdata_fault_events = read_falut_events_stream()

decoded_df = rawdata_fault_events.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_fault_events_schema()).alias("payload"))
#display(rawdata_fault_events.select(col("value").cast("string")))

df1 = decoded_df.select("timestamp", "key", "payload.*")


display(df1)



# COMMAND ----------


blob_service_client = BlobServiceClient.from_connection_string(connection_string)
container_client = blob_service_client.get_container_client(json_container)
blob_client = container_client.get_blob_client('June_15_FM.json')
streamdownloader = blob_client.download_blob()

json_map = json.loads(streamdownloader.readall())
print(json_map)


print(topic_col)


#f=spark.read.json('wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/mappings/June_15_FM.json')
#f.show()

for x in topic_col:
  if x in json_map:
    df1=df1.withColumnRenamed(x,json_map[x])
    print(json_map[x])
  else:
    print(x, "not present")
    
df1.printSchema()

display(df1)