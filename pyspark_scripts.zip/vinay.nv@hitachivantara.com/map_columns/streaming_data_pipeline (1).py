# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql import SparkSession

from pyspark.sql.functions import col, lit
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from time import time
from datetime import datetime

import sys
import os
import time

#Logging 
import logging
import traceback
import sys

from azure.storage.blob import BlobClient, ContainerClient
from pyspark.sql.functions import monotonically_increasing_id 


# COMMAND ----------

#All configuration properties.
confluentBootstrapServers="pkc-ldvmy.centralus.azure.confluent.cloud:9092"
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Confluent account credentials
confluentApiKey="5WYK22HAT2WJ4VIQ"
confluentSecret="bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl"

#Source topics
topic_fault_events="test_nested_events_write"
topic_unit_location="hal_odometer_units"

blob_folder_path = 'streaming-data/fault_events_17'
destination_blob_path = 'wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/'+ blob_folder_path

#Checkpoint paths configured on DBFS
events_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/streaming_delta_57"

db_table_name = "dbo.odometer_location_details"
db_username = "cpodsdwh@cpods-dev-dwh"
db_password = "Azure@2018_Warehouse"
dbname = "cpods-dwh"
servername = "jdbc:sqlserver://cpods-dev-dwh.database.windows.net"
url = servername + ";" + "databaseName=" + dbname + ";"

sql_schema = [StructField('event_id',StringType(),False), StructField('vin',StringType(),False),StructField('latitude',StringType(),False),
              StructField('longitude',StringType(),False), StructField('odometer_date',TimestampType(),False),StructField('created_by',StringType(),False),
              StructField('created_at',TimestampType(),False), StructField('update_by',StringType(),False),StructField('updated_at',TimestampType(),False),
              StructField('odometer_location_pk_id',LongType(),False)]


# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)


# COMMAND ----------

#Creates Spark session
def get_spark(app_name):
    return SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()

#Structured schemas
def create_fault_events_schema():
    return StructType([
            StructField('processingMetadata', StructType([
                 StructField('providerCode', StringType(), True),
                 StructField('eventTime', LongType(), True),
                 StructField('providerProcessedTime', LongType(), True),
                 StructField('pollerProcessedTime', LongType(), True),
                 StructField('vin', StringType(), True),
                 StructField('deviceId', StringType(), True)
                 ])),
              StructField('vehiclePerformanceAttributes', StructType([
                 StructField('engineCoolantLevel', DoubleType(), True),
                 StructField('batteryVoltage', DoubleType(), True),
                 StructField('faultAttributes', StructType([
                       StructField('obdii', StringType(), True),
                       StructField('severity', StringType(), True),
                       StructField('spn', IntegerType(), True),
                       StructField('fmi', IntegerType(), True),
                       StructField('sa', StringType(), True),
                       StructField('occuranceCount', IntegerType(), True),
                       StructField('status', StringType(), True),
                       StructField('description', StringType(), True),
                       StructField('detailDescription', StringType(), True)
                       ])),
                 StructField('oilRelatedAttributes', StructType([
                       StructField('pressure', DoubleType(), True),
                       StructField('level', IntegerType(), True),
                       StructField('temperature', DoubleType(), True)
                       ])),
                  StructField('fuelAttributes', StructType([
                       StructField('fuelLevel', IntegerType(), True),
                       StructField('totalVehicleFuel', DoubleType(), True),
                       StructField('defLevel', StringType(), True)
                       ])) 
                 ])),
              StructField('faultExtension', StructType([
                 StructField('engineInDerate', StringType(), True),
                 StructField('timeLeftToSpeedReduction', IntegerType(), True),
                 StructField('timeLeftToTorqueReduction', DoubleType(), True),
                 StructField('repairInstruction', StringType(), True)
                 ]))
             ])
    
    
def create_unit_location_schema():
    return StructType([
        StructField('processingMetadata', StructType([
             StructField('providerCode', StringType(), True),
             StructField('eventTime', LongType(), True),
             StructField('providerProcessedTime', LongType(), True),
             StructField('pollerProcessedTime', LongType(), True),
             StructField('vin', StringType(), True),
             StructField('deviceId', StringType(), True)
             ])),
          StructField('location', StructType([
             StructField('latitude', DoubleType(), True),
             StructField('longitude', DoubleType(), True),
			 StructField('gpsQuality', StringType(), True)
             ])),
          StructField('locationExtension', StructType([
             StructField('odometer', DoubleType(), True),
             StructField('speed', IntegerType(), True),
             StructField('heading', StringType(), True),
             StructField('fuelLevel', IntegerType(), True),
			 StructField('ignitionState', StringType(), True)
             ]))
         ])

#Functions to flatten the data
def process_fault_events(rawKafka_df):
    #decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_fault_events_schema()).alias("payload"))
    #df1 = decoded_df.select("timestamp", "key", "payload.processingMetadata.*","payload.vehiclePerformanceAttributes.engineCoolantLevel","payload.vehiclePerformanceAttributes.batteryVoltage","payload.vehiclePerformanceAttributes.faultAttributes.*","payload.vehiclePerformanceAttributes.oilRelatedAttributes.*","payload.vehiclePerformanceAttributes.fuelAttributes.*","payload.faultExtension.*")
    #df1 = df1.withColumn("event_timestamp", to_timestamp(expr("from_unixtime(eventTime, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    #df1 = df1.withColumn("process_time", F.unix_timestamp(F.col("timestamp"), 'yyyy-MM-dd HH:mm:ss.SS'))
    #fault code generation on events
    #df1 = df1.withColumn("fault_code", concat_ws('_',df1.spn,df1.fmi,df1.occuranceCount))

    #return df1
    decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), col("value").cast("string").alias("payload"))
    
    return decoded_df
  
def process_odometer_data(raw_df):
    df1 = raw_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_unit_location_schema()).alias("payload"))
    df1 = df1.select("timestamp", "key", "payload.processingMetadata.*","payload.location.*","payload.locationExtension.*")
     #seconds to hour time
    df1 = df1.withColumn("unit_timestamp", to_timestamp(expr("from_unixtime(eventTime, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    return df1
  
#Write to sql server
def write_to_sql(df, df_id):
    try:
        df.write.format("com.microsoft.sqlserver.jdbc.spark") \
            .mode("append") \
            .option("url", url) \
            .option("dbtable", db_table_name) \
            .option("user", db_username) \
            .option("password", db_password) \
            .save()
    except ValueError as error:
        print("Connector write failed", error)
        
def process_micro_batch(input_df, ephoch_id):
  logger.info("======= Streaming batch STARTS ========")
  batch_start_time = time.time()
  #Apply Filter to exclude NULL values from units odo table (which is old data)
  input_df = input_df.filter(col("unitVIN") != 'null')

  #Add extra column by computing difference 
  input_df = input_df.withColumn("closest_duration",
                F.when(F.col("event_time") > F.col("odo_unit_time"), F.col("event_time") - F.col("odo_unit_time")).otherwise(
                F.when(F.col("odo_unit_time") > F.col("event_time"), F.col("odo_unit_time") - F.col("event_time")).otherwise(0))
  )
  # Mapping events to closest odometer records
  windowDuration = Window.partitionBy("eventVIN","event_timestamp").orderBy(col("eventVIN"),col("event_timestamp"),col("closest_duration").asc())
  input_df = input_df.withColumn("rn", row_number().over(windowDuration)).where(col("rn") == 1)
  input_df = input_df.drop("odo_unit_time","event_time", "rn")
  
  input_df = input_df.withColumn("last_updated_ts", F.unix_timestamp(current_timestamp(), 'yyyy-MM-dd HH:mm:ss.SS'))
  
  #Write to blob
  input_df.write.mode("append").partitionBy("last_updated_ts", "eventVIN").parquet(destination_blob_path)
  logger.info("stream is writing to blob with batch id: %s " % ephoch_id)
  time_taken_to_blob_write = time.time() - batch_start_time
  logger.info("Time taken for write to blob : %s seconds" % time_taken_to_blob_write)
  
  prepare_sql_start_time = time.time()
  #Prepare data and write to SQL server.
  write_df = input_df.selectExpr("key as event_id", "unitVIN as vin","cast(latitude as string) latitude", "cast(longitude as string) longitude", \
                                "unit_timestamp as odometer_date")
  write_df = write_df.withColumn("created_by", lit("admin"))\
    .withColumn("created_at", lit(current_timestamp())) \
    .withColumn("update_by", lit("admin")) \
    .withColumn("updated_at", lit(current_timestamp())) \
    .withColumn("odometer_location_pk_id", monotonically_increasing_id())
  sql_df = sqlContext.createDataFrame(write_df.rdd, StructType(sql_schema))
  write_to_sql(sql_df, ephoch_id)

  time_taken_sql = time.time() - prepare_sql_start_time
  logger.info("Time taken for write to DB : %s seconds" % time_taken_sql)
  logger.info("======= Streaming batch ENDS ========")
  

# COMMAND ----------

#Functions to consume streams from kafka topics 
#Topic1:Subscribe to fault_events stream
def read_falut_events_stream():
      raw_fault_events = spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", topic_fault_events)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))
      return process_fault_events(raw_fault_events)
    
#Topic2:Subscribe to unit_locations stream 
def read_odometer_units_stream():
      raw_odometer_data = spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", topic_unit_location)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))
      return process_odometer_data(raw_odometer_data)
      

# COMMAND ----------

#Creates Spark session with default parameters
spark = get_spark("fault events streamining")
#spark.conf.set("spark.sql.streaming.statefulOperator.checkCorrectness.enabled", False)
spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.sparkContext.setLogLevel("ERROR")


# COMMAND ----------

#Step: Read data from kafka topic (events)
events = read_falut_events_stream()

#Step: Read data from kafka topic (unit locations)
units = read_odometer_units_stream()

#Step: watermarks with max 5 minutes late on events
#eventsWithWatermark = events.selectExpr("vin AS eventVIN", "event_timestamp", "eventTime as event_time", "process_time", "fault_code", "key") \
#  .withWatermark("event_timestamp", "5 minutes").dropDuplicates(["eventVIN", "event_time"])




# COMMAND ----------

display(events)