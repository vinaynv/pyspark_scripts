# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql import SparkSession

from pyspark.sql.functions import col, lit
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from time import time
from datetime import datetime

import sys
import os
import time

#Logging 
import logging
import traceback
import sys
import json

from azure.storage.blob import BlobClient, ContainerClient
from pyspark.sql.functions import map_keys, map_values	


# COMMAND ----------

#All configuration properties.
confluentBootstrapServers="pkc-ldvmy.centralus.azure.confluent.cloud:9092"
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Confluent account credentials
confluentApiKey="5WYK22HAT2WJ4VIQ"
confluentSecret="bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl"

#Source topics
source_topic_events="customer_fault_events"  
source_topic_units="customer_odometer_units"

target_topic_events="events_mapping_output"
target_topic_units="units_mapping_output"

#Checkpoint paths configured on DBFS
events_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/map_stream_delta_131"
units_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/map_stream_delta_151"


# COMMAND ----------

#Configure widgets params JSON blob paths
dbutils.widgets.text("events_mapping_json", "")
dbutils.widgets.text("units_mapping_json", "")


# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)


# COMMAND ----------

#Creates Spark session
def get_spark(app_name):
    return SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()

#Structured schemas
def create_fault_events_schema():
    return StructType([
             StructField('event_time_m', StringType(), True),
             StructField('vin_m', StringType(), True),
             StructField('spn_m', StringType(), True),
             StructField('fmi_m', StringType(), True),
             StructField('occr_count_m', StringType(), True),
    ])
    

def create_unit_location_schema():
    return StructType([
      StructField('vin_m', StringType(), True),
      StructField('unit_time_m', StringType(), True),
      StructField('providercode_m', StringType(), True),
      StructField('latitude_m', StringType(), True),
      StructField('longitude_m', StringType(), True),
      StructField('odometer_m', StringType(), True)

      ])
    
def create_fault_events_schema_1():
    return StructType([
            StructField('processingMetadata', StructType([
                 StructField('providerCode', StringType(), True),
                 StructField('eventTime', LongType(), True),
                 StructField('providerProcessedTime', LongType(), True),
                 StructField('pollerProcessedTime', LongType(), True),
                 StructField('vin', StringType(), True),
                 StructField('deviceId', StringType(), True)
                 ])),
              StructField('vehiclePerformanceAttributes', StructType([
                 StructField('engineCoolantLevel', DoubleType(), True),
                 StructField('batteryVoltage', DoubleType(), True),
                 StructField('faultAttributes', StructType([
                       StructField('obdii', StringType(), True),
                       StructField('severity', StringType(), True),
                       StructField('spn', IntegerType(), True),
                       StructField('fmi', IntegerType(), True),
                       StructField('sa', StringType(), True),
                       StructField('occuranceCount', IntegerType(), True),
                       StructField('status', StringType(), True),
                       StructField('description', StringType(), True),
                       StructField('detailDescription', StringType(), True)
                       ])),
                 StructField('oilRelatedAttributes', StructType([
                       StructField('pressure', DoubleType(), True),
                       StructField('level', IntegerType(), True),
                       StructField('temperature', DoubleType(), True)
                       ])),
                  StructField('fuelAttributes', StructType([
                       StructField('fuelLevel', IntegerType(), True),
                       StructField('totalVehicleFuel', DoubleType(), True),
                       StructField('defLevel', StringType(), True)
                       ])) 
                 ])),
              StructField('faultExtension', StructType([
                 StructField('engineInDerate', StringType(), True),
                 StructField('timeLeftToSpeedReduction', IntegerType(), True),
                 StructField('timeLeftToTorqueReduction', DoubleType(), True),
                 StructField('repairInstruction', StringType(), True)
                 ]))
             ])
  


#Functions to flatten the data
def process_fault_events(rawKafka_df):
    decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_fault_events_schema()).alias("payload"))
    df1 = decoded_df.select("timestamp", "key", "payload.event_time_m","payload.vin_m","payload.spn_m","payload.fmi_m","payload.occr_count_m")
    df1 = df1.withColumn("event_timestamp", to_timestamp(expr("from_unixtime(event_time_m, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    df1 = df1.withColumn("process_time", F.unix_timestamp(F.col("timestamp"), 'yyyy-MM-dd HH:mm:ss.SS'))
    #fault code generation on events
    df1 = df1.withColumn("fault_code", concat_ws('_',df1.spn_m,df1.fmi_m,df1.occr_count_m))

    return df1
  
def process_odometer_data(raw_df):
    df1 = raw_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_unit_location_schema()).alias("payload"))
    df1 = df1.select("timestamp", "key", "payload.vin_m","payload.unit_time_m","payload.providercode_m","payload.longitude_m","payload.latitude_m","payload.odometer_m")
     #seconds to hour time
    df1 = df1.withColumn("unit_timestamp", to_timestamp(expr("from_unixtime(unit_time_m, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    return df1
  

  
  

# COMMAND ----------

#Functions to consume streams from kafka topics 
#Topic1:Subscribe to fault_events stream
def read_falut_events_stream():
  raw_fault_events= spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", source_topic_events)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))
  return process_fault_events(raw_fault_events)
    
#Topic2:Subscribe to unit_locations stream 
def read_odometer_units_stream():
      raw_odometer_data = spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", source_topic_units)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))
      return process_odometer_data(raw_odometer_data)
 
 
  
def map_fields(json_df, stream_df):
  fields = []
  df_json = json_df.toJSON()
  for row in df_json.collect():
      dict_items = json.loads(row) 
      for field in dict_items:
        stream_df = stream_df.withColumnRenamed(dict_items[field], field)
        fields.append(field)
  return stream_df
      

# COMMAND ----------

def write_to_topic_events(df, batch_id):
  
  logger.info("======= FM Streaming batch STARTS ========")
  batch_start_time = time.time()
  #Write to kafka
  logger.info("FM EVENTS stream is writing to kafka Topic: %s " % target_topic_events)
  df.selectExpr("CAST(vin AS STRING) AS key", "to_json(struct(*)) AS value") \
     .write \
     .format("kafka") \
     .option("kafka.bootstrap.servers", confluentBootstrapServers) \
     .option("kafka.security.protocol", "SASL_SSL")\
	 .option("failOnDataLoss", "false")\
	 .option("topic", target_topic_events) \
     .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
     .option("kafka.sasl.mechanism", "PLAIN")\
     .option("kafka.ssl.endpoint.identification.algorithm", "https")\
     .save()
  
  time_taken_to_blob_write = time.time() - batch_start_time
  logger.info("Time taken for write to blob : %s seconds" % time_taken_to_blob_write)
  logger.info("======= FM Streaming batch ENDS ========")
  
  
  
def write_to_topic_units(df, batch_id):
  logger.info("======= FM Streaming batch STARTS ========")
  batch_start_time = time.time()
  #Write to kafka
  logger.info("FM uNITS stream is writing to kafka Topic: %s" % target_topic_units)
  
  
  df.selectExpr("CAST(vin AS STRING) AS key", "to_json(struct(*)) AS value") \
     .write \
     .format("kafka") \
     .option("kafka.bootstrap.servers", confluentBootstrapServers) \
     .option("kafka.security.protocol", "SASL_SSL")\
	 .option("failOnDataLoss", "false")\
	 .option("topic", target_topic_units) \
     .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
     .option("kafka.sasl.mechanism", "PLAIN")\
     .option("kafka.ssl.endpoint.identification.algorithm", "https")\
     .save()
  
  time_taken_to_blob_write = time.time() - batch_start_time
  logger.info("Time taken for write to blob : %s seconds" % time_taken_to_blob_write)
  logger.info("======= FM Streaming batch ENDS ========")

# COMMAND ----------

#Creates Spark session with default parameters
spark = get_spark("fault events streamining")
#spark.conf.set("spark.sql.streaming.statefulOperator.checkCorrectness.enabled", False)
spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.sparkContext.setLogLevel("ERROR")

#Step: Read data from kafka topic (events)
events = read_falut_events_stream()
units = read_odometer_units_stream()

input_event_mappings = dbutils.widgets.get("events_mapping_json")
input_unit_mappings = dbutils.widgets.get("units_mapping_json")

events_mapping_json = spark.read.option("multiline","true").json(input_event_mappings)
units_mapping_json = spark.read.option("multiline","true").json(input_unit_mappings)


events_stream_df = map_fields(events_mapping_json, events)
units_stream_df = map_fields(units_mapping_json, units)


events_stream_df=events_stream_df.withColumn("repairInstruction" ,lit("NA"))
events_stream_df=events_stream_df.withColumn("timeLeftToTorqueReduction" ,lit(0))
events_stream_df=events_stream_df.withColumn("timeLeftToSpeedReduction" ,lit(0))
events_stream_df=events_stream_df.withColumn("engineInDerate" ,lit("NA"))

events_stream_df=events_stream_df.withColumn("providerCode" ,lit("tsp1"))
events_stream_df=events_stream_df.withColumn("eventTime" ,col("eventtime"))
events_stream_df=events_stream_df.withColumn("providerProcessedTime" ,col("process_time"))
events_stream_df=events_stream_df.withColumn("pollerProcessedTime" ,col("process_time"))
events_stream_df=events_stream_df.withColumn("deviceId" ,lit("NA"))


events_stream_df=events_stream_df.withColumn("obdii",lit("NA"))
events_stream_df=events_stream_df.withColumn("severity",lit("NA"))
events_stream_df=events_stream_df.withColumn("spn",col("spn"))
events_stream_df=events_stream_df.withColumn("fmi",col("fmi"))
events_stream_df=events_stream_df.withColumn("sa",lit(0))
events_stream_df=events_stream_df.withColumn("occuranceCount",col("occuranceCount"))
events_stream_df=events_stream_df.withColumn("status",lit("NA"))
events_stream_df=events_stream_df.withColumn("description",lit("NA"))
events_stream_df=events_stream_df.withColumn("detailDescription",lit("NA"))


events_stream_df=events_stream_df.withColumn("obdii",lit("NA"))
events_stream_df=events_stream_df.withColumn("severity",lit("NA"))
events_stream_df=events_stream_df.withColumn("spn",col("spn"))
events_stream_df=events_stream_df.withColumn("fmi",col("fmi"))
events_stream_df=events_stream_df.withColumn("sa",lit(0))
events_stream_df=events_stream_df.withColumn("occuranceCount",col("occuranceCount"))
events_stream_df=events_stream_df.withColumn("status",lit("NA"))
events_stream_df=events_stream_df.withColumn("description",lit("NA"))
events_stream_df=events_stream_df.withColumn("detailDescription",lit("NA"))


events_stream_df=events_stream_df.withColumn("pressure",lit(0))
events_stream_df=events_stream_df.withColumn("level",lit(0))
events_stream_df=events_stream_df.withColumn("temperature",lit(0))


events_stream_df=events_stream_df.withColumn("fuelLevel",lit(0))
events_stream_df=events_stream_df.withColumn("totalVehicleFuel",lit(0))
events_stream_df=events_stream_df.withColumn("defLevel",lit(0))


events_stream_df=events_stream_df.withColumn("engineCoolantLevel",lit(0))
events_stream_df=events_stream_df.withColumn("batteryVoltage",lit(0))

tt=events_stream_df.select("key",struct(struct("providerCode", "eventTime","providerProcessedTime","pollerProcessedTime","vin","deviceId").alias("processingMetadata")
                          ,struct("engineCoolantLevel","batteryVoltage"
                          ,struct("obdii","severity","spn","fmi","sa","occuranceCount","status","description","detailDescription").alias("faultAttributes")
                          ,struct("pressure","level","temperature").alias("oilRelatedAttributes")
                          ,struct("fuelLevel","totalVehicleFuel","defLevel").alias("fuelAttributes")).alias("vehiclePerformanceAttributes")
                          ,struct("engineInDerate","timeLeftToSpeedReduction", "timeLeftToTorqueReduction","repairInstruction").alias("faultExtension")
                          ).alias("valuestr"))


    
ff=tt.withColumn("value",to_json(col("valuestr"))).select("key","value")

display(ff)



# COMMAND ----------

def write_to_topic_events_test(df, batch_id):
  
  logger.info("======= FM Streaming batch STARTS ========")
  batch_start_time = time.time()
  #Write to kafka
  logger.info("FM EVENTS stream is writing to kafka Topic: %s " % target_topic_events)
    
  df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)") \
  .write \
  .format("kafka") \
     .option("kafka.bootstrap.servers", confluentBootstrapServers) \
     .option("kafka.security.protocol", "SASL_SSL")\
	 .option("failOnDataLoss", "false")\
	 .option("topic", "test_nested_events_write") \
     .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
     .option("kafka.sasl.mechanism", "PLAIN")\
     .option("kafka.ssl.endpoint.identification.algorithm", "https")\
     .save()
  
  #display(df)
  #df.withColumn("strJson",{"processingMetadata":{"providerCode": "tsp1", "eventTime": col("eventtime").cast(IntegerType()), "providerProcessedTime": col("process_time").cast(IntegerType()), "pollerProcessedTime": col("process_time").cast(IntegerType()), "vin": col("vin"), "deviceId": "NA"}, "vehiclePerformanceAttributes": { "engineCoolantLevel": 0,  "batteryVoltage": 0, "faultAttributes": {"obdii": "NA", "severity": "NA", "spn": col("spn").cast(IntegerType()), "fmi": col("fmi").cast(IntegerType()), "sa": 0, "occuranceCount": col("occuranceCount").cast(IntegerType()), "status": "NA", "description": "NA", "detailDescription": "NA"}, "oilRelatedAttributes": { "pressure": 0,"level": 0, "temperature": 0}, "fuelAttributes": { "fuelLevel": 0, "totalVehicleFuel": 0, "defLevel": 0}}, "faultExtension": {"engineInDerate": 0, "timeLeftToSpeedReduction": 0, "timeLeftToTorqueReduction": 0, "repairInstruction": "NA"}})
  
  #df.selectExpr("CAST(vin AS STRING) AS key", "to_json(struct(*)) AS value") \
  #   .write \
  #   .format("kafka") \
  #   .option("kafka.bootstrap.servers", confluentBootstrapServers) \
  #   .option("kafka.security.protocol", "SASL_SSL")\
	# .option("failOnDataLoss", "false")\
	# .option("topic", "write_to_nested") \
    # .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
    # .option("kafka.sasl.mechanism", "PLAIN")\
    # .option("kafka.ssl.endpoint.identification.algorithm", "https")\
    # .save()
  
  time_taken_to_blob_write = time.time() - batch_start_time
  logger.info("Time taken for write to blob : %s seconds" % time_taken_to_blob_write)
  logger.info("======= FM Streaming batch ENDS ========")

# COMMAND ----------

#events_stream_df.select(col('eventtime'),col('vin'),col('spn'),col('fmi')).writeStream.trigger(processingTime="120 seconds") \
ff.writeStream.trigger(processingTime="120 seconds") \
  .option("checkpointLocation", events_checkpoint_path)\
  .foreachBatch(write_to_topic_events_test)\
  .queryName("mappingEventsStreamingQuery").start() 

# COMMAND ----------

#display(events_stream_df)
display(ff)

# COMMAND ----------


#Write to KAFKA as a micro batch
#events_stream_df.writeStream.trigger(processingTime="120 seconds") \
#  .option("checkpointLocation", events_checkpoint_path)\
#  .foreachBatch(write_to_topic_events)\
#  .queryName("mappingEventsStreamingQuery").start()

#Write to KAFKA as a micro batch
#units_stream_df.writeStream.trigger(processingTime="120 seconds") \
#     .option("checkpointLocation", units_checkpoint_path)\
#     .foreachBatch(write_to_topic_units)\
#     .queryName("mappingUnitsStreamingQuery").start()

# COMMAND ----------

#events_stream_df