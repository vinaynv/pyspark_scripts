# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql.functions import col, lit
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, TimestampType

#from pyspark.sql.window import Window
#from pyspark.sql.functions import col, row_number
#from uuid import uuid4
#from time import time
#import schedule

#Logging 
import logging
#import traceback
#import sys

from azure.storage.blob import BlobClient, ContainerClient


# COMMAND ----------

#All configuration properties.
confluentBootstrapServers="pkc-ldvmy.centralus.azure.confluent.cloud:9092"
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Confluent account credentials
confluentApiKey="5WYK22HAT2WJ4VIQ"
confluentSecret="bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl"

#Source topics
topic_fault_incident="cpods_ro_rc_merge"
#topic_unit_location="cf_unit_location_events_anuja"

#Destination blob store
destination_blob_path1 = 'confluent/fcpods_Incident_merged_streamed_data_2'
incident_destination_path = 'wasbs://cpods-kafka-storage@cpodsdev.blob.core.windows.net/'+ destination_blob_path1

#Checkpoint paths configured on DBFS
incident_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/fcpods_Incident_merged_streamed_data_2"


# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)


# COMMAND ----------

#Structured schemas
def create_incident_schema():
    return StructType([
            StructField('unit_key', LongType(), True),
            StructField('unit_num', StringType(), True),
            StructField('unit_vin', StringType(), True),
            StructField('unit_corp_cd', StringType(), True),
            StructField('rc_key', LongType(), True),
            StructField('repairing_location_key', LongType(), True),
            StructField('ro_processed_date_key', LongType(), True),
            StructField('ro_rc_num', StringType(), True),
            StructField('comp_code', StringType(), True),    
            StructField('source_code_flag', StringType(), True),
            StructField('roadcall_flag', StringType(), True), 
            StructField('customer_wait_flag', StringType(), True),
            StructField('ro_rc_flag', StringType(), True),
		    StructField('pm_flag', StringType(), True),
            StructField('profile_id', StringType(), True),
            StructField('ro_rc_date_utc', LongType(), True),
		    StructField('ro_rc_start_date_utc', LongType(), True),
            StructField('ro_rc_end_date_utc', LongType(), True),
		    StructField('tier', IntegerType(), True),
            StructField('subset', LongType(), True),
		    StructField('day_light_saving_flag', StringType(), True),
            StructField('time_zone_cd', StringType(), True),
		    StructField('job_complaint', StringType(), True),
            StructField('job_cause', StringType(), True),
		    StructField('job_description', StringType(), True),
            StructField('partition_key', LongType(), True),
		    StructField('ro_accounting_month_key', StringType(), True),
            StructField('ro_seq_num', StringType(), True),
		    StructField('ent_admin_cntl', StringType(), True),
            StructField('odometer', DoubleType(), True),
		    StructField('wo_status', StringType(), True),
            StructField('job_status', StringType(), True),
		    StructField('job_id', StringType(), True),
            StructField('wo_workorder', StringType(), True),
		    StructField('pm_type', StringType(), True),
            StructField('first_wo_start_date_utc', LongType(), True),
		    StructField('last_wo_start_date_utc', LongType(), True),
            StructField('first_wo_complete_date_utc', LongType(), True),
		    StructField('last_wo_complete_date_utc', LongType(), True),
            StructField('first_job_start_date_utc', LongType(), True),        
            StructField('last_job_start_date_utc', LongType(), True),
            StructField('first_job_complete_date_utc', LongType(), True),
            StructField('last_job_complete_date_utc', LongType(), True),
            StructField('record_insert_date', LongType(), True),
		    StructField('record_change_date', LongType(), True),
            StructField('capture_datetime', LongType(), True)    
            ])
    
    


# COMMAND ----------

#Functions to consume streams from kafka topics 
#Topic1:Subscribe to incident stream
def read_incident_stream():
      return spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", topic_fault_incident)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))
    


# COMMAND ----------

#Functions to flatten the data
def prepare_incident_flat_df(rawKafka_df):
    decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_incident_schema()).alias("payload"))
    df1 = decoded_df.select("timestamp", "key", "payload.*")
    #seconds to hour time
    df1 = df1.withColumn("HourlyeventTs_old", col("ro_rc_end_date_utc")/3600)
    df1 = df1.withColumn("incident_timestamp", to_timestamp(expr("from_unixtime(ro_rc_end_date_utc, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    df1 = df1.withColumn("HourlyeventTs", df1.HourlyeventTs_old.cast('integer'))
    df1 = df1.withColumn("last_updated_ts", F.unix_timestamp(current_timestamp(), 'yyyy-MM-dd HH:mm:ss.SS'))
    df1 = df1.withColumnRenamed("timestamp","processing_time")
    return df1
  
  
#Write stream to blob
def write_results_to_blob(df, ephoch_id):
      df.write.mode("append").partitionBy("unit_vin","last_updated_ts") \
      .parquet(incident_destination_path)
    


# COMMAND ----------

# STEP 1 : creating spark session object
spark = (
      spark.builder.appName("Incident Streaming")
      .master("local[*]")
      .getOrCreate()
  )

spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.conf.set("spark.sql.streaming.statefulOperator.checkCorrectness.enabled", False)
spark.sparkContext.setLogLevel("ERROR")

#Step-2: Fault events start here
#Step-2.1 Read data from kafka topic
rawdata_incident = read_incident_stream()
#Step:2.2 Convert raw data to flat df
incident = prepare_incident_flat_df(rawdata_incident)
#Write results to blob 
incident.writeStream.trigger(processingTime="120 seconds") \
  .option("checkpointLocation", incident_checkpoint_path)\
  .foreachBatch(write_results_to_blob) \
  .queryName("query10").start()

# COMMAND ----------

display(incident)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Validate Data

# COMMAND ----------

#incident_data = spark.read.format("parquet").load(incident_destination_path)
#display(incident_data)

# COMMAND ----------

