# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql import SparkSession

from pyspark.sql.functions import col, lit
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, LongType, TimestampType, MapType

import pyspark.sql.functions as fn

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from time import time
from datetime import datetime

import sys
import os
import time

#Logging 
import logging
import traceback
import sys
import json

from azure.storage.blob import BlobClient, ContainerClient
from pyspark.sql.functions import map_keys, map_values	

from confluent_kafka.schema_registry import SchemaRegistryClient



# COMMAND ----------

#All configuration properties.
confluentBootstrapServers="pkc-ldvmy.centralus.azure.confluent.cloud:9092"
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Confluent account credentials
confluentApiKey="5WYK22HAT2WJ4VIQ"
confluentSecret="bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl"

#Source topics
source_topic_events="event_data_schema_test"  
source_topic_units="customer_odometer_units"

target_topic_events="events_mapping_output"
target_topic_units="units_mapping_output"

#Checkpoint paths configured on DBFS
events_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/map_stream_delta_1345"
units_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/map_stream_delta_1545"

confluentRegistryApiKey="Z5YNYU7PWAD7DPWZ"
confluentRegistrySecret="SNUZ5TqdXB8u+v96EgJn4PQDEJoP2YLzlVYqE1Nwo1gGPDPmaibyWwCM9kb++wph"


# COMMAND ----------

#Configure widgets params JSON blob paths
dbutils.widgets.text("events_mapping_json", "")
dbutils.widgets.text("units_mapping_json", "")


# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)


# COMMAND ----------

#Creates Spark session
def get_spark(app_name):
    return SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()



#Functions to flatten the data
def process_fault_events(rawKafka_df):
    decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_fault_events_schema()).alias("payload"))
    df1 = decoded_df.select("timestamp", "key", "payload.event_time_m","payload.vin_m","payload.spn_m","payload.fmi_m","payload.occr_count_m")
    df1 = df1.withColumn("event_timestamp", to_timestamp(expr("from_unixtime(event_time_m, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    df1 = df1.withColumn("process_time", F.unix_timestamp(F.col("timestamp"), 'yyyy-MM-dd HH:mm:ss.SS'))
    #fault code generation on events
    df1 = df1.withColumn("fault_code", concat_ws('_',df1.spn_m,df1.fmi_m,df1.occr_count_m))

    return df1

  

  
  

# COMMAND ----------

schema_registry_conf = {
    'url': 'https://psrc-q2n1d.westus2.azure.confluent.cloud',
    'basic.auth.user.info': '{}:{}'.format(confluentRegistryApiKey, confluentRegistrySecret)}

schema_registry_client = SchemaRegistryClient(schema_registry_conf)
subjects = schema_registry_client.get_subjects()

binary_to_string = fn.udf(lambda x: str(int.from_bytes(x, byteorder='big')), StringType())


clickstreamTestDf = (
  spark
  .readStream
  .format("kafka")
  .option("kafka.bootstrap.servers", confluentBootstrapServers)
  .option("kafka.security.protocol", "SASL_SSL")
  .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))
  .option("kafka.ssl.endpoint.identification.algorithm", "https")
  .option("kafka.sasl.mechanism", "PLAIN")
  .option("subscribe", "event_data_schema_test")
  .option("startingOffsets", "earliest")
  .option("failOnDataLoss", "false")
  .load()
  .withColumn('key', fn.col("key").cast(StringType()))
  .withColumn('fixedValue', fn.expr("substring(value, 6, length(value)-5)"))
  .withColumn('valueSchemaId', binary_to_string(fn.expr("substring(value, 2, 4)")))
  .withColumn('valueSchemaId_bs', fn.expr("substring(value, 2, 4)").cast("string"))
  .withColumn('value_s', col('value').cast("string"))
  .select('topic', 'partition', 'offset', 'timestamp', 'timestampType', 'key', 'valueSchemaId','valueSchemaId_bs','value_s','fixedValue')
)


# COMMAND ----------

display(clickstreamTestDf) 

# COMMAND ----------

def parseAvroDataWithSchemaId(df, ephoch_id):
  cachedDf = df.cache()
  
  fromAvroOptions = {"mode":"FAILFAST"}
  
  def getSchema(id):
    return str(schema_registry_client.get_schema(id).schema_str)

  distinctValueSchemaIdDF = cachedDf.select(fn.col('valueSchemaId').cast('integer')).distinct()

  for valueRow in distinctValueSchemaIdDF.collect():

    currentValueSchemaId = sc.broadcast(valueRow.valueSchemaId)
    currentValueSchema = sc.broadcast(getSchema(currentValueSchemaId.value))
    
    filterValueDF = cachedDf.filter(fn.col('valueSchemaId') == currentValueSchemaId.value)
    
    filterValueDF \
      .select('topic', 'partition', 'offset', 'timestamp', 'timestampType', 'key', from_avro('fixedValue', currentValueSchema.value, fromAvroOptions).alias('parsedValue')) \
      .write \
      .format("delta") \
      .mode("append") \
      .option("mergeSchema", "true") \
     .save(deltaTablePath)

# COMMAND ----------

clickstreamTestDf.writeStream \
  .option("checkpointLocation", events_checkpoint_path) \
  .foreachBatch(parseAvroDataWithSchemaId) \
  .queryName("clickStreamTestFromConfluent") \
  .start()

# COMMAND ----------

#deltaClickstreamTestDf = spark.read.format("delta").load(deltaTablePath)
#display(deltaClickstreamTestDf)

# COMMAND ----------

