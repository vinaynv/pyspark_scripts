# Databricks notebook source
from confluent_kafka.avro import AvroProducer
import avro.schema
import csv
from uuid import uuid4
from avro.datafile import DataFileReader, DataFileWriter
from avro.io import DatumReader, DatumWriter
import pandas as pd
import json
import time
from confluent_kafka import avro

from confluent_kafka import SerializingProducer
from confluent_kafka.serialization import StringSerializer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroSerializer

kafka_topic_name="avro_customer_fault_event"
confluentRegistryApiKey="Z5YNYU7PWAD7DPWZ"
confluentRegistrySecret="SNUZ5TqdXB8u+v96EgJn4PQDEJoP2YLzlVYqE1Nwo1gGPDPmaibyWwCM9kb++wph"

print("Starting Kafka Producer")

print("connecting to Kafka topic...")

schema_registry_conf = {
    'url': 'https://psrc-q2n1d.westus2.azure.confluent.cloud',
    'basic.auth.user.info': '{}:{}'.format(confluentRegistryApiKey, confluentRegistrySecret)}

schema_registry_client = SchemaRegistryClient(schema_registry_conf)

schema = schema_registry_client.get_latest_version(kafka_topic_name+'-value')
print(schema.version)
print(schema.schema_id)
print(schema.schema.schema_str)
print(schema.subject)
avschma=schema.schema.schema_str

avro_serializer = AvroSerializer(schema_registry_client = schema_registry_client, schema_str=avschma)


conf = {
        'bootstrap.servers' : 'pkc-ldvmy.centralus.azure.confluent.cloud:9092',
        'security.protocol' : 'SASL_SSL',
        'sasl.mechanisms' : 'PLAIN',
        'sasl.username': '5WYK22HAT2WJ4VIQ',
        'sasl.password': 'bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl',
        'value.serializer' : avro_serializer
        }
key_schema_string = """
    {"type": "string"}
    """
key_schema = avro.loads(key_schema_string)

value_schema = avro.loads(avschma)

producer = SerializingProducer(conf)


with open("/dbfs/FileStore/tables/events_map-3.csv","r") as file:
  data = pd.read_csv(file)
  #data= csv.DictReader(file, delimiter=",")
  #for row in data:
  for ind in data.index:
    
    publish_data = {"event_time_m": int(time.time()), "vin_m": str(data.vin_m[ind]), "spn_m": int(data.spn_m[ind]), "fmi_m": int(data.fmi_m[ind]), "occr_count_m": int(data.occr_count_m[ind])}
    
    #value = json.dumps(publish_data)
    #encoded_event_data = json.dumps(publish_data, indent=2).encode('utf-8')
    #print(encoded_event_data)
    #print(publish_data)
    try:
      producer.produce(topic=kafka_topic_name,key=str(uuid4()), value=publish_data)
    except Exception as e:
      print(f"Exception while producing record value - {publish_data} to topic - {kafka_topic_name}: {e}")
    else:
      print(f"Successfully producing record value - {publish_data} to topic - {kafka_topic_name}")	
   
      
    producer.flush()
file.close()