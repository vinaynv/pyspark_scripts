# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql.functions import col, lit
from pyspark.sql import SparkSession
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from uuid import uuid4
from time import *
import time
from datetime import datetime as dt

#Logging 
import logging
import traceback
import sys
import os

import json
import argparse
import collections   
import requests
from requests.exceptions import HTTPError

from azure.storage.blob import BlobClient, BlobServiceClient, ContainerClient

# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)

# COMMAND ----------

cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Event Source blob store
source_blob_path = 'streaming-data/fault_events_17'
azure_source_path = 'wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/'+ source_blob_path

#Event Source blob store
eve_source_blob_path = 'streaming-data/fault_events_17'
eve_azure_source_path = 'wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/'+ eve_source_blob_path

#Incident Source blob store
inc_source_blob_path = 'confluent/Incident_merged_streamed_data_10'
inc_azure_source_path = 'wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/'+ inc_source_blob_path



source_container = 'cpods-kafka-storage'
target_container ='cpods-dev-storage'

blob_folder_path = 'penske_predict/seq/pq_1rec/'
target_blob_path = 'wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/'+ blob_folder_path

connection_string = 'DefaultEndpointsProtocol=https;AccountName=cpodsdev;AccountKey=fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg==;EndpointSuffix=core.windows.net'

p0_endpoint = 'https://fleetmaintenance-fp-cpods.azurewebsites.net/batch'


# COMMAND ----------

def get_spark(app_name):
    """
        Creates Spark session with default parameters
    """
    spark = SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()

    # Other hadoop configs
    #hadoop_config = spark.sparkContext._jsc.hadoopConfiguration()
    #hadoop_config.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)

    return spark

# COMMAND ----------

#Creates Spark session with default parameters
spark = get_spark("fault events aggregations")
spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.sparkContext.setLogLevel("ERROR")


# COMMAND ----------

def get_p0_predictions(filePath):
    """ This function sends request to the URL and get prediction
    in the form of response"""
    try:
      # Send the post request and get response   
      logger.info("Input blob to model : %s" % filePath)
      data = json.dumps({"jobId": "df80fc82-2bd3-4099-a70d-pensketry2", 
                          "modelName": "fleet_maintenance.penske_models",
                          "predictionInput": {
                            "modelPath": "Model_Output/",
                            "dataFormat": "JSON",
                            "args": [ "--sensor_data_paths", filePath ], 
                            "fromSource": "File Storage",
                            "toTarget": "Database", 
                            "sourceType": "parquet"
                          } })
      headers = {"content-type": "application/json"}
      logger.info('API request %s' , data)
      requestStartTime = time.time()
      response = requests.post(p0_endpoint, data=data, headers=headers)
      timeTaken = time.time() - requestStartTime
      logger.info('Time taken for model predicions : %f seconds' % timeTaken)
      returnResponse = None
      
      if response.status_code == requests.codes.ok:
         returnResponse = response
      else:
          logger.info('Model API returns HTTP error %s for input file: %s', response.status_code, filePath)
          response.raise_for_status()
    except HTTPError as http_err:
        logger.error(http_err)
        pass
    except Exception as err:
        logger.error(err)
        pass
    return returnResponse

#Create azure blob service client
def create_blob_service_client(source_container_connection_string, source_container_name):
    container_client = None
    try:
        blob_source_service_client = BlobServiceClient.from_connection_string(source_container_connection_string)
        container_client = blob_source_service_client.get_container_client(source_container_name)
    except Exception as ex:
        logger.info("Getting blob connection :" , repr(ex))
        raise Exception("Error while creating azure blob container client.")
        
    return container_client
  
# Preapre a list with blob images from source path 
def isBlobExists(connection_client, inutSourceFolderPath):
    isExists = False
    blob_names = []
    try:
        blob_list = connection_client.list_blobs(inutSourceFolderPath)
        for blob in blob_list:
            blob_name = blob.name
            #logger.info("blob_name: %s" % blob_name)
            if blob_name.find("part-") != -1 :
                #connection_client.delete_blob(blob=blob_name)
                #blob_names.append(blob_name)
                isExists = True
        #print(blob_names)
    except Exception as ex:
        logger.error("Exception occured while preparing blobs list... %s", str(ex))
        
    return isExists


# COMMAND ----------

def run_pipeline_inc():
  
  all_incident_data=spark.read.format("parquet").load(inc_azure_source_path)
  inc_five_mins=all_incident_data.filter(col("last_updated_ts") >= (F.unix_timestamp(current_timestamp(), 'yyyy-MM-dd HH:mm:ss.SS') - 900)).select(col("unit_vin").alias("vin")).distinct().collect()

  
  all_data= spark.read.format("parquet").load(eve_azure_source_path)
  eve_five_mins=all_data.filter(col("last_updated_ts") >= (F.unix_timestamp(current_timestamp(), 'yyyy-MM-dd HH:mm:ss.SS') - 900)).select(col("eventVIN").alias("vin")).distinct().collect()
  
  #donot use
  #.filter(col("last_updated_ts") >= (current_timestamp() - expr("INTERVAL 5 minutes"))) \
  
  all_vins=list(set(inc_five_mins) | set(eve_five_mins))
  
  all_vins_list = [row.vin for row in all_vins]
  
  eve_vin_data=all_data.filter(col("eventVIN").isin(all_vins_list))
 
  inc_vin_data=all_incident_data.filter(col("unit_vin").isin(all_vins_list)).groupBy(col("unit_vin")) \
    .agg(max(col("ro_rc_end_date_utc")).alias("ro_rc_end_date_utc")).select(col("unit_vin"),col("ro_rc_end_date_utc"))
    
  #inc_event_merge_join=eve_vin_data.join(inc_vin_data,eve_vin_data.eventVIN == inc_vin_data.unit_vin,"leftouter") \
  #  .withColumn("un_dt_event_timestamp",unix_timestamp(col("event_timestamp")))
  
  inc_event_merge=eve_vin_data.join(inc_vin_data,eve_vin_data.eventVIN == inc_vin_data.unit_vin,"leftouter") \
    .filter(col("unit_vin").isNull() | (unix_timestamp(col("event_timestamp")) >= col("ro_rc_end_date_utc"))) \
    .withColumn("un_dt_event_timestamp",unix_timestamp(col("event_timestamp")))
    
  windowVin = Window.partitionBy("eventVIN").orderBy(col("event_timestamp").desc())
  five_k_rec=inc_event_merge.withColumn("row", row_number().over(windowVin)).filter(col("row") <= 5000)
  
  global seq_data
  
  seq_data = five_k_rec.groupBy("eventVIN")\
  .agg(concat_ws(",", collect_list("fault_code")).alias("fault_seq"), concat_ws(",", collect_list("odometer")).alias("mileage_seq"), 
             concat_ws(",", collect_list("event_timestamp")).alias("event_ts_seq"), first("key").alias("uniquestr"),
             first('providerCode').alias("providercode"), first('process_time').alias("processing_time")) \
  .select(col("eventVIN").alias("vin"), col("fault_seq"), col("event_ts_seq"), col("mileage_seq"), col("uniquestr"), col("providercode"), 
                lit("Un Resolved").alias("status"), col("processing_time"))

  
  partition_folder_name = dt.now().strftime("%Y%m%d-%H%M%S")
  target_blob = target_blob_path + partition_folder_name
  blob_dir_path = blob_folder_path + partition_folder_name
  #Write to blob
  logger.info('Relative blob path for model API: %s ' % blob_dir_path)
  seq_data.write.mode(saveMode="append").parquet(target_blob)
  logger.info('=======seq_data written to blob ============')
  client = create_blob_service_client(connection_string, target_container)
  while True:
    time.sleep(10)
    isExists = isBlobExists(client, blob_dir_path)
    logger.info('Is blob exists : %s' % isExists)
    if isExists :
        response = get_p0_predictions(blob_dir_path)
        if response == None:
            logger.error("Response is none from model : %s ", response)
            return None
        if response.status_code == requests.codes.ok:
            json_output = json.loads(response.text)
            logger.info('model response: %s ', json_output)
            if "ERROR" in json_output:
                logger.error("model output as JSON : ", json_output)

        break
    else:
            logger.info('Parquet file not yet created.')

# COMMAND ----------

def main():
    job_start_time = time.time()
    logger.info('========== JOB-2 STARTED :==========' )
    try:
        run_pipeline_inc()
        execution_time = time.time() - job_start_time
        logger.info("Time taken to complete Job-2: %s seconds" % execution_time)
        logger.info("========== JOB-2 ENDS ===========>>" )
    except Exception as ex:
        logger.info(f"{traceback.format_exc()}")
        logger.info("Exception from main:" , ex)

if __name__ == "__main__":
    main()