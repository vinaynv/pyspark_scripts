# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql.functions import col, lit
from pyspark.sql import SparkSession
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from uuid import uuid4
from time import *
import time
from datetime import datetime as dt

#Logging 
import logging
import traceback
import sys
import os

import json
import argparse
import collections   
import requests
from requests.exceptions import HTTPError

from azure.storage.blob import BlobClient, BlobServiceClient, ContainerClient

# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)

# COMMAND ----------

cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Source blob store
inc_source_blob_path = 'confluent/vin_Incident_merged_streamed_data_110'
inc_azure_source_path = 'wasbs://cpods-kafka-storage@cpodsdev.blob.core.windows.net/'+ inc_source_blob_path

eve_source_blob_path = 'confluent/vin_p1_streaming_event_data_31'
eve_azure_source_path = 'wasbs://cpods-kafka-storage@cpodsdev.blob.core.windows.net/'+ eve_source_blob_path

cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

source_container = 'cpods-kafka-storage'
target_container ='cpods-dev-storage'

blob_folder_path = 'penske_predict/seq/pq_3rec/'
target_blob_path = 'wasbs://cpods-dev-storage@cpodsdev.blob.core.windows.net/'+ blob_folder_path

connection_string = 'DefaultEndpointsProtocol=https;AccountName=cpodsdev;AccountKey=fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg==;EndpointSuffix=core.windows.net'

p0_endpoint = 'https://fleetmaintenance-fp-cpods.azurewebsites.net/batch'


# COMMAND ----------

def get_spark(app_name):
    """
        Creates Spark session with default parameters
    """
    spark = SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()

    # Other hadoop configs
    hadoop_config = spark.sparkContext._jsc.hadoopConfiguration()
    hadoop_config.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)

    return spark

# COMMAND ----------

#Creates Spark session with default parameters
spark = get_spark("fault events aggregations")
spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.sparkContext.setLogLevel("ERROR")


# COMMAND ----------

def merge_inc_event():
  all_incident_data=spark.read.format("parquet").load(inc_azure_source_path)
  #inc_one_hour=all_incident_data.filter(col("processing_time") >= current_timestamp() - expr("INTERVAL 1 HOURS") )
  grp_inc_data=all_incident_data.groupBy(col("unit_vin")) \
  .agg(max(col("ro_rc_end_date_utc")).alias("ro_rc_end_date_utc"),max(col("odometer")).alias("odometer"))\
  .select(col("unit_vin"),col("ro_rc_end_date_utc"),col("odometer"))

  dist_inc_one_hour=grp_inc_data.select(col("unit_vin")).collect()
  dist_inc_list=[row.unit_vin for row in dist_inc_one_hour]

  logger.info(dist_inc_list)

  if(len(dist_inc_list) > 0):
    all_event_data= spark.read.format("parquet").load(eve_azure_source_path)
    #even_one_hour= all_event_data.filter(col("last_updated_ts") >= (F.unix_timestamp(current_timestamp(), 'yyyy-MM-dd HH:mm:ss.SS') - 3600))
    even_vin_data=all_event_data.filter(col("eventVIN").isin(dist_inc_list))
    #display(all_event_data)
    inc_event_merge=even_vin_data.join(grp_inc_data,even_vin_data.eventVIN == grp_inc_data.unit_vin,"inner") \
    .filter(unix_timestamp(col("event_timestamp")) >= col("ro_rc_end_date_utc")).withColumn("un_dt_event_timestamp",unix_timestamp(col("event_timestamp")))

    inc_seq_data = even_vin_data.orderBy("eventVIN","event_timestamp").groupBy("eventVIN") \
              .agg(concat_ws(",", collect_list("fault_code")).substr(0, 5000).alias("fault_seq"), concat_ws(",", collect_list("odometer")).alias("mileage_seq"), 
                   concat_ws(",", collect_list("event_timestamp")).alias("event_ts_seq"), first("key").alias("uniquestr"),
                   first('providerCode').alias("providercode"), first('process_time').alias("processing_time")) \
              .select(col("eventVIN").alias("vin"), col("fault_seq"), col("event_ts_seq"), col("mileage_seq"), col("uniquestr"), col("providercode"), 
                      lit("Un Resolved").alias("status"), col("processing_time") )
    
    



# COMMAND ----------

display(grp_inc_data)
display(inc_event_merge)
display(inc_seq_data)