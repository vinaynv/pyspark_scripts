# Databricks notebook source
from confluent_kafka import Producer
import avro.schema
import csv
from uuid import uuid4
from avro.datafile import DataFileReader, DataFileWriter
from avro.io import DatumReader, DatumWriter
import pandas as pd
import json
import time

kafka_topic_name="cpods_fault_events"

print("Starting Kafka Producer")    
conf = {
        'bootstrap.servers' : 'pkc-ldvmy.centralus.azure.confluent.cloud:9092',
        'security.protocol' : 'SASL_SSL',
        'sasl.mechanisms' : 'PLAIN',
        'sasl.username': '5WYK22HAT2WJ4VIQ',
        'sasl.password': 'bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl'
        }
          
print("connecting to Kafka topic...")


def delivery_report(errmsg, msg):
    """
    Reports the Failure or Success of a message delivery.
    Args:
        errmsg  (KafkaError): The Error that occured while message producing.
        data    (Actual message): The message that was produced.
    Note:
        In the delivery report callback the Message.key() and Message.value()
        will be the binary format as encoded by any configured Serializers and
        not the same object that was passed to produce().
        If you wish to pass the original object(s) for key and value to delivery
        report callback we recommend a bound callback or lambda where you pass
        the objects along.
    """    
    if errmsg is not None:
        print("Delivery failed for Message: {} : {}".format(msg.key(), errmsg))
        return
    print('Message: {} successfully produced to Topic: {} Partition: [{}] at offset {}'.format(
        msg.key(), msg.topic(), msg.partition(), msg.offset()))

#schema = avro.schema.parse(open("/dbfs/confluent_kafka/resources/cf_unit_fault_events.avsc").read())
producer = Producer(conf)
  
# Trigger any available delivery report callbacks from previous produce() calls 
producer.poll(0)

with open("/dbfs/FileStore/tables/events_rorc_ind.csv","r") as file:
  data = pd.read_csv(file)
  for ind in data.index:
#    publish_data = {"processingMetadata":{"providerCode": data.providercode[ind], "eventTime": int(data.eventtime[ind]), "providerProcessedTime": int(data.providerprocessedtime[ind]), "pollerProcessedTime": int(data.pollerprocessedtime[ind]), "vin": data.vin[ind], "deviceId": str(data.deviceid[ind])}, "vehiclePerformanceAttributes": { "engineCoolantLevel": int(data.enginecoolantlevel[ind]),  "batteryVoltage": int(data.batteryvoltage[ind]), "faultAttributes": {"obdii": data.obdii[ind], "severity": data.severity[ind], "spn": int(data.spn[ind]), "fmi": int(data.fmi[ind]), "sa": int(data.sa[ind]), "occuranceCount": int(data.occurancecount[ind]), "status": data.status[ind], "description": data.description[ind], "detailDescription": str(data.detaildescription[ind])}, "oilRelatedAttributes": { "pressure": int(data.pressure[ind]),"level": int(data.level[ind]), "temperature": int(data.temperature[ind])}, "fuelAttributes": { "fuelLevel": int(data.fuellevel[ind]), "totalVehicleFuel": int(data.totalvehiclefuel[ind]), "defLevel": int(data.deflevel[ind])}}, "faultExtension": {"engineInDerate": int(data.engineinderate[ind]), "timeLeftToSpeedReduction": int(data.timelefttospeedreduction[ind]), "timeLeftToTorqueReduction": int(data.timelefttotorquereduction[ind]), "repairInstruction": data.repairinstruction[ind]}}
    publish_data = {"processingMetadata":{"providerCode": data.providercode[ind], "eventTime": int(time.time()), "providerProcessedTime": int(time.time()), "pollerProcessedTime": int(time.time()), "vin": data.vin[ind], "deviceId": str(data.deviceid[ind])}, "vehiclePerformanceAttributes": { "engineCoolantLevel": int(data.enginecoolantlevel[ind]),  "batteryVoltage": int(data.batteryvoltage[ind]), "faultAttributes": {"obdii": data.obdii[ind], "severity": data.severity[ind], "spn": int(data.spn[ind]), "fmi": int(data.fmi[ind]), "sa": int(data.sa[ind]), "occuranceCount": int(data.occurancecount[ind]), "status": data.status[ind], "description": data.description[ind], "detailDescription": str(data.detaildescription[ind])}, "oilRelatedAttributes": { "pressure": int(data.pressure[ind]),"level": int(data.level[ind]), "temperature": int(data.temperature[ind])}, "fuelAttributes": { "fuelLevel": int(data.fuellevel[ind]), "totalVehicleFuel": int(data.totalvehiclefuel[ind]), "defLevel": int(data.deflevel[ind])}}, "faultExtension": {"engineInDerate": int(data.engineinderate[ind]), "timeLeftToSpeedReduction": int(data.timelefttospeedreduction[ind]), "timeLeftToTorqueReduction": int(data.timelefttotorquereduction[ind]), "repairInstruction": data.repairinstruction[ind]}}
    encoded_event_data = json.dumps(publish_data, indent=2).encode('utf-8')
    #print(encoded_event_data)
    #print(publish_data)
    producer.produce(topic=kafka_topic_name, key=str(uuid4()), value=encoded_event_data, on_delivery=delivery_report)
    producer.flush()
file.close()
del data

# COMMAND ----------

#display(data)
#del data

# COMMAND ----------

#data.info()