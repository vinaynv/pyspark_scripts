# Databricks notebook source
from confluent_kafka import Producer
import avro.schema
import csv,time
from uuid import uuid4
from avro.datafile import DataFileReader, DataFileWriter
from avro.io import DatumReader, DatumWriter
import pandas as pd
import json

kafka_topic_name="hal_incident_data"

print("Starting Kafka Producer")
conf = {
        'bootstrap.servers' : 'pkc-ldvmy.centralus.azure.confluent.cloud:9092',
        'security.protocol' : 'SASL_SSL',
        'sasl.mechanisms' : 'PLAIN',
        'sasl.username': '5WYK22HAT2WJ4VIQ',
        'sasl.password': 'bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl'
        }
          
print("connecting to Kafka topic...")


def delivery_report(errmsg, msg):
    """
    Reports the Failure or Success of a message delivery.
    Args:
        errmsg  (KafkaError): The Error that occured while message producing.
        data    (Actual message): The message that was produced.
    Note:
        In the delivery report callback the Message.key() and Message.value()
        will be the binary format as encoded by any configured Serializers and
        not the same object that was passed to produce().
        If you wish to pass the original object(s) for key and value to delivery
        report callback we recommend a bound callback or lambda where you pass
        the objects along.
    """    
    if errmsg is not None:
        print("Delivery failed for Message: {} : {}".format(msg.key(), errmsg))
        return
    print('Message: {} successfully produced to Topic: {} Partition: [{}] at offset {}'.format(
        msg.key(), msg.topic(), msg.partition(), msg.offset()))

producer = Producer(conf)
  
# Trigger any available delivery report callbacks from previous produce() calls
producer.poll(0)

#/dbfs/FileStore/tables/merge_ro_rc_ind.csv
 
with open("/dbfs/FileStore/tables/merge_ro_rc_ind_1.csv","r") as file:
  data = pd.read_csv(file)
  for ind in data.index:
#    publish_data = {"unit_key": int(data.unit_key[ind]), "unit_num": data.unit_num[ind], "unit_vin": data.unit_vin[ind], "unit_corp_cd": data.unit_corp_cd[ind], "rc_key": data.rc_key[ind], "repairing_location_key" : int(data.repairing_location_key[ind]), "ro_processed_date_key" : int(data.ro_processed_date_key[ind]) ,"comp_code": data.comp_code[ind], "ro_rc_date_utc": int(data.ro_rc_date_utc[ind]), "ro_rc_start_date_utc": int(data.ro_rc_start_date_utc[ind]), "ro_rc_end_date_utc": int(data.ro_rc_end_date_utc[ind]), "tier": data.tier[ind], "subset": data.subset[ind], "time_zone_cd": data.time_zone_cd[ind], "job_complaint": data.job_complaint[ind], "job_cause": data.job_cause[ind], "job_description": data.job_description[ind], "odometer": data.odometer[ind], "capture_datetime": int(data.capture_datetime[ind])}
    publish_data = {"unit_key": int(data.unit_key[ind]), "unit_num": data.unit_num[ind], "unit_vin": data.unit_vin[ind], "unit_corp_cd": data.unit_corp_cd[ind], "rc_key": data.rc_key[ind], "repairing_location_key" : int(data.repairing_location_key[ind]), "ro_processed_date_key" : int(data.ro_processed_date_key[ind]) ,"comp_code": data.comp_code[ind], "ro_rc_date_utc": int(time.time()-2), "ro_rc_start_date_utc": int(time.time()-2), "ro_rc_end_date_utc": int(time.time()-2), "tier": data.tier[ind], "subset": data.subset[ind], "time_zone_cd": data.time_zone_cd[ind], "job_complaint": data.job_complaint[ind], "job_cause": data.job_cause[ind], "job_description": data.job_description[ind], "odometer": data.odometer[ind], "capture_datetime": int(time.time()-2)}
    encoded_event_data = json.dumps(publish_data, indent=2).encode('utf-8')
    #print(encoded_event_data)
    #print(publish_data)
    producer.produce(topic=kafka_topic_name, key=str(uuid4()), value=encoded_event_data, on_delivery=delivery_report)
    producer.flush()
file.close()
del data