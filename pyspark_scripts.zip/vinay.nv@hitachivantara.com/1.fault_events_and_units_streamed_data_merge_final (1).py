# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql.functions import col, lit
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from uuid import uuid4
from time import time
#import schedule

#Logging 
import logging
import traceback
import sys

from azure.storage.blob import BlobClient, ContainerClient


# COMMAND ----------

#All configuration properties.
confluentBootstrapServers="pkc-ldvmy.centralus.azure.confluent.cloud:9092"
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Confluent account credentials
confluentApiKey="5WYK22HAT2WJ4VIQ"
confluentSecret="bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl"

#Source topics
topic_fault_events="cf_unit_fault_events_vinay"
topic_unit_location="cf_unit_location_events_vinay"

#Destination blob store
destination_blob_path1 = 'confluent/merge_streamed_data_4'
events_destination_path = 'wasbs://cpods-kafka-storage@cpodsdev.blob.core.windows.net/'+ destination_blob_path1

#Checkpoint paths configured on DBFS
events_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/p0_events_odo_data_24"


# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)


# COMMAND ----------

#Structured schemas
def create_fault_events_schema():
    return StructType([
            StructField('processingMetadata', StructType([
                 StructField('providerCode', StringType(), True),
                 StructField('eventTime', LongType(), True),
                 StructField('providerProcessedTime', LongType(), True),
                 StructField('pollerProcessedTime', LongType(), True),
                 StructField('vin', StringType(), True),
                 StructField('deviceId', StringType(), True)
                 ])),
              StructField('vehiclePerformanceAttributes', StructType([
                 StructField('engineCoolantLevel', DoubleType(), True),
                 StructField('batteryVoltage', DoubleType(), True),
                 StructField('faultAttributes', StructType([
                       StructField('obdii', StringType(), True),
                       StructField('severity', StringType(), True),
                       StructField('spn', IntegerType(), True),
                       StructField('fmi', IntegerType(), True),
                       StructField('sa', StringType(), True),
                       StructField('occuranceCount', IntegerType(), True),
                       StructField('status', StringType(), True),
                       StructField('description', StringType(), True),
                       StructField('detailDescription', StringType(), True)
                       ])),
                 StructField('oilRelatedAttributes', StructType([
                       StructField('pressure', DoubleType(), True),
                       StructField('level', IntegerType(), True),
                       StructField('temperature', DoubleType(), True)
                       ])),
                  StructField('fuelAttributes', StructType([
                       StructField('fuelLevel', IntegerType(), True),
                       StructField('totalVehicleFuel', DoubleType(), True),
                       StructField('defLevel', StringType(), True)
                       ])) 
                 ])),
              StructField('faultExtension', StructType([
                 StructField('engineInDerate', StringType(), True),
                 StructField('timeLeftToSpeedReduction', IntegerType(), True),
                 StructField('timeLeftToTorqueReduction', DoubleType(), True),
                 StructField('repairInstruction', StringType(), True)
                 ]))
             ])
    
    
def create_unit_location_schema():
    return StructType([
        StructField('processingMetadata', StructType([
             StructField('providerCode', StringType(), True),
             StructField('eventTime', LongType(), True),
             StructField('providerProcessedTime', LongType(), True),
             StructField('pollerProcessedTime', LongType(), True),
             StructField('vin', StringType(), True),
             StructField('deviceId', StringType(), True)
             ])),
          StructField('location', StructType([
             StructField('latitude', DoubleType(), True),
             StructField('longitude', DoubleType(), True),
			 StructField('gpsQuality', StringType(), True)
             ])),
          StructField('locationExtension', StructType([
             StructField('odometer', DoubleType(), True),
             StructField('speed', IntegerType(), True),
             StructField('heading', StringType(), True),
             StructField('fuelLevel', IntegerType(), True),
			 StructField('ignitionState', StringType(), True)
             ]))
         ])


# COMMAND ----------

#Functions to consume streams from kafka topics 
#Topic1:Subscribe to fault_events stream
def read_falut_events_stream():
      return spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", topic_fault_events)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))
    
#Topic2:Subscribe to unit_locations stream 
def read_unit_location_stream():
      return spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", topic_unit_location)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))
  
#.option("kafka.group.id", "test.streams")\

# COMMAND ----------

#Functions to flatten the data
def prepare_fault_events_flat_df(rawKafka_df):
    decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_fault_events_schema()).alias("payload"))
    df1 = decoded_df.select("timestamp", "key", "payload.processingMetadata.*","payload.vehiclePerformanceAttributes.engineCoolantLevel","payload.vehiclePerformanceAttributes.batteryVoltage","payload.vehiclePerformanceAttributes.faultAttributes.*","payload.vehiclePerformanceAttributes.oilRelatedAttributes.*","payload.vehiclePerformanceAttributes.fuelAttributes.*","payload.faultExtension.*")
    #seconds to hour time
    df1 = df1.withColumn("five_min_ts", (col("eventTime")/300).cast('integer'))
    df1 = df1.withColumn("event_timestamp", to_timestamp(expr("from_unixtime(eventTime, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    #df1 = df1.withColumn("HourlyeventTs", df1.HourlyeventTs_old.cast('integer'))
    df1 = df1.withColumnRenamed("timestamp","processing_time")
    return df1
  
def prepare_unit_location_flat_df(raw_df):
    df1 = raw_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_unit_location_schema()).alias("payload"))
    df1 = df1.select("timestamp", "key", "payload.processingMetadata.*","payload.location.*","payload.locationExtension.*")
     #seconds to hour time
    #df1 = df1.withColumn("HourlyeventTs_old", col("eventTime")/3600) 
    df1 = df1.withColumn("five_min_ts", (col("eventTime")/300).cast('integer'))
    #df1 = df1.withColumn("HourlyeventTs",df1.HourlyeventTs_old.cast('integer'))
    df1 = df1.withColumnRenamed("timestamp","processing_time") 
    df1 = df1.withColumn("unit_timestamp", to_timestamp(expr("from_unixtime(eventTime, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    return df1
  
#Write stream to blob
def write_results_to_blob(df, ephoch_id):
      df.write.mode("append").partitionBy("eventVIN") \
      .parquet(events_destination_path)
    


# COMMAND ----------


del events
del units
del merged_df
del eventsWithWatermark
del unitsWithWatermark



# COMMAND ----------

# STEP 1 : creating spark session object
spark = (
      spark.builder.appName("Fault Events Streamining")
      .master("local[*]")
      .getOrCreate()
  )

spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.conf.set("spark.sql.streaming.statefulOperator.checkCorrectness.enabled", False)
spark.sparkContext.setLogLevel("ERROR")

#Step-2: Fault events start here
#Step-2.1 Read data from kafka topic
rawdata_fault_events = read_falut_events_stream()
#Step:2.2 Convert raw data to flat df
events = prepare_fault_events_flat_df(rawdata_fault_events)

#Step:3- Unit loc start here
#Step-3.1 Read data from kafka topic
rawdata_fault_unit_locs = read_unit_location_stream()
#Step:3.2 Convert raw data to flat df
units = prepare_unit_location_flat_df(rawdata_fault_unit_locs)

# Define watermarks with max 5 minutes late
eventsWithWatermark = events.selectExpr("vin AS eventVIN", "event_timestamp", "eventTime as event_time", "spn", "fmi" ,"occuranceCount") \
  .withWatermark("event_timestamp", "5 minutes").dropDuplicates(["eventVIN", "event_time"])

unitsWithWatermark = units \
  .selectExpr("vin AS unitVIN", "unit_timestamp", "eventTime as odo_unit_time","odometer", "processing_time", "providerCode", "key") \
  .withWatermark("unit_timestamp", "5 minutes").dropDuplicates(["unitVIN", "odo_unit_time"])

merged_df = eventsWithWatermark.join(
  unitsWithWatermark,
  expr(""" 
   eventVIN = unitVIN AND 
    (unit_timestamp <= event_timestamp + interval 5 minutes AND unit_timestamp >= event_timestamp - interval 5 minutes)
    """
  ),"leftOuter"
)

#Add extra column by computing difference 
merged_df = merged_df.withColumn("closest_duration",
              F.when(F.col("event_time") > F.col("odo_unit_time"), F.col("event_time") - F.col("odo_unit_time")).otherwise(
              F.when(F.col("odo_unit_time") > F.col("event_time"), F.col("odo_unit_time") - F.col("event_time")).otherwise(0))
)

#Apply Filter to exclude NULL values from units odo table (which is old data)
merged_df = merged_df.filter(col("unitVIN") != 'null')

#TODO
#df_basket1 = df_basket1.select("Item_group","Item_name","Price", F.row_number().over(Window.partitionBy().orderBy(df_basket1['price'])).alias("row_num"))



#fff= merged_df.select(col("eventVIN"),col("event_timestamp"),col("event_time"),col("spn"),col("fmi"),col("occuranceCount"),col("unitVIN"),col("unit_timestamp"),col("odo_unit_time"),col("processing_time"),col("providerCode"),col("key"),col("closest_duration"),F.row_number().over(Window.partitionBy(merged_df['eventVIN'],merged_df['event_timestamp']).orderBy(merged_df['eventVIN'],merged_df['event_timestamp'],merged_df['closest_duration'].asc())).alias("row_num"))


#units.writeStream.trigger(processingTime="120 seconds").outputMode('append').format('console').start()
#events.writeStream.trigger(processingTime="120 seconds").outputMode('append').format('console').start()
#merged_df.writeStream.trigger(processingTime="120 seconds").outputMode('append').format('console').start()

def process_for_each(df, ephoch_id):
  df.write.mode("append").format('console').save()
  #display(df)
  #print("***************************************************inside for each***********************************************************")
  #df.write.mode("append").format("console").text("***************************************************inside for each***********************************************************").start()
  #df.show()
  windowDuration = Window.partitionBy("eventVIN","event_timestamp").orderBy(col("eventVIN"),col("event_timestamp"),col("closest_duration").asc())
  df1=df.withColumn("rn", row_number().over(windowduration)).where(col("rn") == 1)
  
  #df1=df.select(col("eventVIN"),col("event_timestamp"),col("event_time"),col("spn"),col("fmi"),col("occuranceCount"),col("unitVIN"),col("unit_timestamp"), col("odo_unit_time"),col("processing_time"),col("providerCode"),col("key"),col("closest_duration"), F.row_number().over(Window.partitionBy(col('eventVIN'),col('event_timestamp')).orderBy(col('eventVIN'),col('event_timestamp'),col('closest_duration').asc())).alias("row_num"))
  df1.write.mode("append").format('console').save()
  
  #df2=df1.filter(col("row_num")==1)
  #df2.write.mode("append").format('console').save()


merged_df.writeStream.trigger(processingTime="120 seconds").foreachBatch(process_for_each).start()

#.outputMode('append').format('console').start()
 

#Write results to blob 
#merged_df.writeStream.trigger(processingTime="120 seconds") \
#  .foreachBatch(write_results_to_blob) \
#  .start()

#merged_df.writeStream.trigger(processingTime="120 seconds") \
#  .option("checkpointLocation", events_checkpoint_path)\
#  .foreachBatch(write_results_to_blob) \
#  .queryName("query1").start()


# COMMAND ----------

decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_fault_events_schema()).alias("payload"))

# COMMAND ----------

display(events)

# COMMAND ----------

display(units)

# COMMAND ----------

display(merged_df)

# COMMAND ----------

merged_df.groupBy("event_timestamp").min("closest_duration")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Validate Data

# COMMAND ----------

merge_data = spark.read.format("parquet").load(events_destination_path)
display(merge_data)

# COMMAND ----------

