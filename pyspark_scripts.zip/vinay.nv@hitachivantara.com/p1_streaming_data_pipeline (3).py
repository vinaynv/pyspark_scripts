# Databricks notebook source
#Required libraries.
import ssl
from pyspark.sql import SparkSession

from pyspark.sql.functions import col, lit
from pyspark.sql.avro.functions import from_avro, to_avro
from datetime import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, TimestampType

from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number
from uuid import uuid4
from time import time

import sys
import os

#Logging 
import logging
import traceback
import sys

from azure.storage.blob import BlobClient, ContainerClient


# COMMAND ----------

#All configuration properties.
confluentBootstrapServers="pkc-ldvmy.centralus.azure.confluent.cloud:9092"
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

#Confluent account credentials
confluentApiKey="5WYK22HAT2WJ4VIQ"
confluentSecret="bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl"

#Source topics
topic_fault_events="cpods_fault_events"
topic_unit_location="cpods_location_events"

#Destination blob store
destination_blob_path1 = 'confluent/vin_p1_streaming_event_data_0003'
events_destination_path = 'wasbs://cpods-kafka-storage@cpodsdev.blob.core.windows.net/'+ destination_blob_path1

#Checkpoint paths configured on DBFS
events_checkpoint_path ="dbfs:/delta/p0_streams/checkpoints/vin_p1_streaming_event_data_0003"


# COMMAND ----------

logger = logging.getLogger(__name__)
if not logger.handlers:
  logger.setLevel(logging.INFO)
  logger.propagate = False
  format = logging.Formatter('%(asctime)-2s - %(levelname)-2s: %(funcName)s %(lineno)d: %(message)s')
  streamHandler = logging.StreamHandler()
  streamHandler.setFormatter(format)
  logger.addHandler(streamHandler)


# COMMAND ----------

#Structured schemas
def create_fault_events_schema():
    return StructType([
            StructField('processingMetadata', StructType([
                 StructField('providerCode', StringType(), True),
                 StructField('eventTime', LongType(), True),
                 StructField('providerProcessedTime', LongType(), True),
                 StructField('pollerProcessedTime', LongType(), True),
                 StructField('vin', StringType(), True),
                 StructField('deviceId', StringType(), True)
                 ])),
              StructField('vehiclePerformanceAttributes', StructType([
                 StructField('engineCoolantLevel', DoubleType(), True),
                 StructField('batteryVoltage', DoubleType(), True),
                 StructField('faultAttributes', StructType([
                       StructField('obdii', StringType(), True),
                       StructField('severity', StringType(), True),
                       StructField('spn', IntegerType(), True),
                       StructField('fmi', IntegerType(), True),
                       StructField('sa', StringType(), True),
                       StructField('occuranceCount', IntegerType(), True),
                       StructField('status', StringType(), True),
                       StructField('description', StringType(), True),
                       StructField('detailDescription', StringType(), True)
                       ])),
                 StructField('oilRelatedAttributes', StructType([
                       StructField('pressure', DoubleType(), True),
                       StructField('level', IntegerType(), True),
                       StructField('temperature', DoubleType(), True)
                       ])),
                  StructField('fuelAttributes', StructType([
                       StructField('fuelLevel', IntegerType(), True),
                       StructField('totalVehicleFuel', DoubleType(), True),
                       StructField('defLevel', StringType(), True)
                       ])) 
                 ])),
              StructField('faultExtension', StructType([
                 StructField('engineInDerate', StringType(), True),
                 StructField('timeLeftToSpeedReduction', IntegerType(), True),
                 StructField('timeLeftToTorqueReduction', DoubleType(), True),
                 StructField('repairInstruction', StringType(), True)
                 ]))
             ])
    
    
def create_unit_location_schema():
    return StructType([
        StructField('processingMetadata', StructType([
             StructField('providerCode', StringType(), True),
             StructField('eventTime', LongType(), True),
             StructField('providerProcessedTime', LongType(), True),
             StructField('pollerProcessedTime', LongType(), True),
             StructField('vin', StringType(), True),
             StructField('deviceId', StringType(), True)
             ])),
          StructField('location', StructType([
             StructField('latitude', DoubleType(), True),
             StructField('longitude', DoubleType(), True),
			 StructField('gpsQuality', StringType(), True)
             ])),
          StructField('locationExtension', StructType([
             StructField('odometer', DoubleType(), True),
             StructField('speed', IntegerType(), True),
             StructField('heading', StringType(), True),
             StructField('fuelLevel', IntegerType(), True),
			 StructField('ignitionState', StringType(), True)
             ]))
         ])


# COMMAND ----------

#Functions to consume streams from kafka topics 
#Topic1:Subscribe to fault_events stream
def read_falut_events_stream():
      return spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", topic_fault_events)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))
    
#Topic2:Subscribe to unit_locations stream 
def read_unit_location_stream():
      return spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", confluentBootstrapServers)\
        .option("kafka.security.protocol", "SASL_SSL")\
        .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))\
        .option("kafka.ssl.endpoint.identification.algorithm", "https")\
        .option("kafka.sasl.mechanism", "PLAIN")\
        .option("subscribe", topic_unit_location)\
        .option("startingOffsets", "earliest")\
        .option("failOnDataLoss", "false")\
        .option("includeHeaders", "true")\
        .load() \
        .select(col("timestamp"), col("key"), col("value"))

# COMMAND ----------

#Functions to flatten the data
def prepare_fault_events_flat_df(rawKafka_df):
    decoded_df = rawKafka_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_fault_events_schema()).alias("payload"))
    df1 = decoded_df.select("timestamp", "key", "payload.processingMetadata.*","payload.vehiclePerformanceAttributes.engineCoolantLevel","payload.vehiclePerformanceAttributes.batteryVoltage","payload.vehiclePerformanceAttributes.faultAttributes.*","payload.vehiclePerformanceAttributes.oilRelatedAttributes.*","payload.vehiclePerformanceAttributes.fuelAttributes.*","payload.faultExtension.*")
    df1 = df1.withColumn("event_timestamp", to_timestamp(expr("from_unixtime(eventTime, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    df1 = df1.withColumn("process_time", F.unix_timestamp(F.col("timestamp"), 'yyyy-MM-dd HH:mm:ss.SS'))
    #fault code generation on events
    df1 = df1.withColumn("fault_code", concat_ws('_',df1.spn,df1.fmi,df1.occuranceCount))

    return df1
  
def prepare_unit_location_flat_df(raw_df):
    df1 = raw_df.select(col("timestamp"), col('key').cast("string"), from_json(col("value").cast("string"), create_unit_location_schema()).alias("payload"))
    df1 = df1.select("timestamp", "key", "payload.processingMetadata.*","payload.location.*","payload.locationExtension.*")
     #seconds to hour time
    df1 = df1.withColumn("unit_timestamp", to_timestamp(expr("from_unixtime(eventTime, 'yyyy-MM-dd HH:mm:ss.SSSS')")))
    return df1
  
#Write stream to blob
def write_results_to_blob(df, ephoch_id):
      df.write.mode("append").partitionBy("eventVIN") \
      .parquet(events_destination_path)
    


# COMMAND ----------

def process_for_each(input_df, ephoch_id):
  windowDuration = Window.partitionBy("eventVIN","event_timestamp").orderBy(col("eventVIN"),col("event_timestamp"),col("closest_duration").asc())
  input_df = input_df.withColumn("rn", row_number().over(windowDuration)).where(col("rn") == 1)
  input_df = input_df.drop("unit_timestamp", "odo_unit_time","event_time", "rn")
  input_df = input_df.withColumn("last_updated_ts", F.unix_timestamp(current_timestamp(), 'yyyy-MM-dd HH:mm:ss.SS'))
  input_df.write.mode("append").partitionBy("last_updated_ts", "eventVIN").parquet(events_destination_path)



# COMMAND ----------

def get_spark(app_name):
    """
        Creates Spark session with default parameters
    """
    spark = SparkSession.builder \
        .master(os.environ.get("SPARK_MASTER", "local[*]")) \
        .appName(app_name) \
        .config("spark.default.parallelism", 16) \
        .enableHiveSupport() \
        .getOrCreate()

    return spark

# COMMAND ----------

#Creates Spark session with default parameters
spark = get_spark("fault events streamining")
spark.conf.set("spark.sql.streaming.statefulOperator.checkCorrectness.enabled", False)
spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)
spark.sparkContext.setLogLevel("ERROR")


# COMMAND ----------

#Step: Read data from kafka topic (events)
rawdata_fault_events = read_falut_events_stream()
#Step: Convert raw data to flat df
events = prepare_fault_events_flat_df(rawdata_fault_events)

#Step: Read data from kafka topic (unit locations)
rawdata_fault_unit_locs = read_unit_location_stream()
#Step: Convert raw data to flat df
units = prepare_unit_location_flat_df(rawdata_fault_unit_locs)

#Step: watermarks with max 5 minutes late on events
eventsWithWatermark = events.selectExpr("vin AS eventVIN", "event_timestamp", "eventTime as event_time", "process_time", "fault_code", "key") \
  .withWatermark("event_timestamp", "5 minutes").dropDuplicates(["eventVIN", "event_time"])

#Step: watermarks with max 5 minutes late on units
unitsWithWatermark = units \
  .selectExpr("vin AS unitVIN", "unit_timestamp", "eventTime as odo_unit_time","odometer", "providerCode") \
  .withWatermark("unit_timestamp", "5 minutes").dropDuplicates(["unitVIN", "odo_unit_time"])

# Join events with unit locations
merged_df = eventsWithWatermark.join(
  unitsWithWatermark,
  expr(""" 
   eventVIN = unitVIN AND 
      (unit_timestamp <= event_timestamp + interval 5 minutes AND unit_timestamp >= event_timestamp - interval 5 minutes)
    """
  ),"leftOuter"
)

#Add extra column by computing difference 
merged_df = merged_df.withColumn("closest_duration",
              F.when(F.col("event_time") > F.col("odo_unit_time"), F.col("event_time") - F.col("odo_unit_time")).otherwise(
              F.when(F.col("odo_unit_time") > F.col("event_time"), F.col("odo_unit_time") - F.col("event_time")).otherwise(0))
)

#Apply Filter to exclude NULL values from units odo table (which is old data)
merged_df = merged_df.filter(col("unitVIN") != 'null')

#Write to blob
merged_df.writeStream.trigger(processingTime="120 seconds") \
.option("checkpointLocation", events_checkpoint_path)\
.foreachBatch(process_for_each)\
.queryName("query1").start()


# COMMAND ----------

display(merged_df)