# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This notebook is to parse streaming data from confluent kafka and store in a azure datalake /DBFS.

# COMMAND ----------

import pyspark.sql.functions as fn
from pyspark.sql.types import StringType
from pyspark.sql.avro.functions import from_avro

from confluent_kafka.schema_registry import SchemaRegistryClient
import ssl


# COMMAND ----------

# MAGIC %md
# MAGIC The following are the keys and secrets to connect to confluent cloud and schema registry 

# COMMAND ----------

confluentApiKey="5WYK22HAT2WJ4VIQ"
confluentSecret="bBJwE6r0bKmCKLWqYx5D71TyzLhZ0TK2Hdi+V3kz/WahUb+5F83yadSE3s21ysTl"
confluentRegistryApiKey="Z5YNYU7PWAD7DPWZ"
confluentRegistrySecret="SNUZ5TqdXB8u+v96EgJn4PQDEJoP2YLzlVYqE1Nwo1gGPDPmaibyWwCM9kb++wph"

schemaRegistryUrl = "https://psrc-q2n1d.westus2.azure.confluent.cloud"
confluentTopicName="cust_eve_data"
confluentBootstrapServers="pkc-ldvmy.centralus.azure.confluent.cloud:9092"
cpodsdev_access_key="fYHMib7Ufp1eJgbZMWD7m7oVVkmruitI12GuuQ3mU0KueyLejULmKoA4uUhDtZ53bh5qv0EJCwGICVuWyeOqZg=="

# COMMAND ----------

#spark configuration
#spark.conf.set("fs.azure.account.key.cpodsadlsgen2.blob.core.windows.net", adlsGen2Key)
spark.conf.set("fs.azure.account.key.cpodsdev.blob.core.windows.net", cpodsdev_access_key)

# schema registry  
schema_registry_conf = {
    'url': schemaRegistryUrl,
    'basic.auth.user.info': '{}:{}'.format(confluentRegistryApiKey, confluentRegistrySecret)}

schema_registry_client = SchemaRegistryClient(schema_registry_conf)

# COMMAND ----------

# MAGIC %md
# MAGIC Read stream from Kafka topic

# COMMAND ----------

# Convert binary stream data to string 
binary_to_string = fn.udf(lambda x: str(int.from_bytes(x, byteorder='big')), StringType())

# Read stream from kafka topic and convert it to spark dataframe 
clickstreamTestDf = (
  spark
  .readStream
  .format("kafka")
  .option("kafka.bootstrap.servers", confluentBootstrapServers)
  .option("kafka.security.protocol", "SASL_SSL")
  .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))
  .option("kafka.ssl.endpoint.identification.algorithm", "https")
  .option("kafka.sasl.mechanism", "PLAIN")
  .option("subscribe", confluentTopicName)
  .option("startingOffsets", "earliest")
  .option("failOnDataLoss", "false")
  .load()
  .withColumn('key', fn.col("key").cast(StringType()))
  .withColumn('fixedValue', fn.expr("substring(value, 6, length(value)-5)"))
  .withColumn('valueSchemaId', binary_to_string(fn.expr("substring(value, 2, 4)")))
  .select('topic', 'partition', 'offset', 'timestamp', 'timestampType', 'key', 'valueSchemaId','fixedValue')
)

# COMMAND ----------

fromAvroOptions = {"mode":"FAILFAST"}
def getSchema(id):
  return str(schema_registry_client.get_schema(id).schema_str)

currentValueSchema = getSchema(100023)
tt=clickstreamTestDf.select('topic', 'partition', 'offset', 'timestamp', 'timestampType', 'key', from_avro('fixedValue', currentValueSchema, fromAvroOptions).alias('parsedValue'))



display(tt)


# COMMAND ----------

# MAGIC %md
# MAGIC Visulaize streamed data as a Dataframe

# COMMAND ----------

# Write data to DBFS file store 
clickstreamTestDf.writeStream \
  .foreachBatch(parseAvroDataWithSchemaId) \
  .queryName("clickStreamTestFromConfluent") \
  .start()


# Display data from spark Dataframe



# COMMAND ----------

# MAGIC %md
# MAGIC Target location to save the data

# COMMAND ----------

# DBFS/Datalake target paths
deltaTablePath = "dbfs:/delta/nag/testKafkaStream"
checkpointPath = "dbfs:/delta/nag/checkpoints/testKafkaStream"


# COMMAND ----------

# MAGIC %md
# MAGIC The following function loads the schema by ID which is registred at confluent cloud .
# MAGIC Iterate over each data row and validates the data with registered schema at confluent and filter the columns and stored as a Dataframe.

# COMMAND ----------


def parseAvroDataWithSchemaId(df, ephoch_id):
  cachedDf = df.cache()
  
  fromAvroOptions = {"mode":"FAILFAST"}
  
  def getSchema(id):
    return str(schema_registry_client.get_schema(id).schema_str)

  distinctValueSchemaIdDF = cachedDf.select(fn.col('valueSchemaId').cast('integer')).distinct()

  for valueRow in distinctValueSchemaIdDF.collect():

    currentValueSchemaId = sc.broadcast(valueRow.valueSchemaId)
    currentValueSchema = sc.broadcast(getSchema(currentValueSchemaId.value))
    
    filterValueDF = cachedDf.filter(fn.col('valueSchemaId') == currentValueSchemaId.value)
    
    filterValueDF \
      .select('topic', 'partition', 'offset', 'timestamp', 'timestampType', 'key', from_avro('fixedValue', currentValueSchema.value, fromAvroOptions).alias('parsedValue')) \
      .write \
      .format("delta") \
      .mode("append") \
      .option("mergeSchema", "true") \
     .save(deltaTablePath)


# COMMAND ----------

# MAGIC %md
# MAGIC Write data to DBFS

# COMMAND ----------

# Write data to DBFS file store 
clickstreamTestDf.writeStream \
  .option("checkpointLocation", checkpointPath) \
  .foreachBatch(parseAvroDataWithSchemaId) \
  .queryName("clickStreamTestFromConfluent") \
  .start()

# COMMAND ----------

# MAGIC %md
# MAGIC Read data from DBFS 

# COMMAND ----------

def convert_bytes(size, unit="MB"):
    if unit == "KB":
        return print('File size: ' + str(round(size / 1024, 3)) + ' Kilobytes')
    elif unit == "MB":
        return print('File size: ' + str(round(size / (1024 * 1024), 3)) + ' Megabytes')
    elif unit == "GB":
        return print('File size: ' + str(round(size / (1024 * 1024 * 1024), 3)) + ' Gigabytes')
    else:
        return print('File size: ' + str(size) + ' bytes')




# COMMAND ----------

# MAGIC %md
# MAGIC Loading data to verfiy the content size and it's existence.

# COMMAND ----------

deltaClickstreamTestDf = spark.read.format("delta").load(deltaTablePath)
print(deltaClickstreamTestDf.count())

sizeInBytes = spark._jsparkSession.sessionState().executePlan(deltaClickstreamTestDf._jdf.queryExecution().logical()).optimizedPlan().stats().sizeInBytes()
convert_bytes(sizeInBytes)

# COMMAND ----------

# MAGIC %md
# MAGIC Save data to azure blob container

# COMMAND ----------

# Save data on azure blob storage
destination_path_blob = "wasbs://cpods-kafka-storage@cpodsdev.blob.core.windows.net/confluent/refined_parquet_data"

# COMMAND ----------

def parseAvroDataWithSchemaIdAndWriteToBlob(df, ephoch_id):
  cachedDf = df.cache()
  
  fromAvroOptions = {"mode":"FAILFAST"}
  
  def getSchema(id):
    return str(schema_registry_client.get_schema(id).schema_str)

  distinctValueSchemaIdDF = cachedDf.select(fn.col('valueSchemaId').cast('integer')).distinct()

  for valueRow in distinctValueSchemaIdDF.collect():

    currentValueSchemaId = sc.broadcast(valueRow.valueSchemaId)
    currentValueSchema = sc.broadcast(getSchema(currentValueSchemaId.value))
    
    filterValueDF = cachedDf.filter(fn.col('valueSchemaId') == currentValueSchemaId.value)
    
    filterValueDF \
      .select('topic', 'partition', 'offset', 'timestamp', 'timestampType', 'key', from_avro('fixedValue', currentValueSchema.value,          fromAvroOptions).alias('parsedValue')) \
      .write.mode("append").parquet(destination_path_blob)


# COMMAND ----------

# Write data to DBFS file store 
clickstreamTestDf.writeStream \
  .foreachBatch(parseAvroDataWithSchemaIdAndWriteToBlob) \
  .queryName("clickStreamTestFromConfluentToBlob") \
  .start()

# COMMAND ----------

# MAGIC %md
# MAGIC Read stream data from parquet file located at azure blob storage

# COMMAND ----------

parquetStreamDfFromBlobStorage = spark.read.format("parquet").load(destination_path_blob)
print('No.of Rows : ', parquetStreamDfFromBlobStorage.count())
sizeInBytes = spark._jsparkSession.sessionState().executePlan(parquetStreamDfFromBlobStorage._jdf.queryExecution().logical()).optimizedPlan().stats().sizeInBytes()
convert_bytes(sizeInBytes)

# COMMAND ----------

